Скрипты являются примером выполнения шагов сертификации в соответствии с регламентом. 
Регламент предоставляется тех. поддержкой (help@moex.com)
Для запуска примеров необходим python2 версии > 2.6, либо python3 версии > 3.3
----
These scripts is a sample implementation of certification procedure in accordance with the regulations provided by tech support (help@moex.com).
Python 2.6 or Python 3.3 is required to run them.