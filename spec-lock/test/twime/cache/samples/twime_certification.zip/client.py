#!/usr/bin/env python

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

import socket
import struct

from serializer import Serializer


class Client(object):

    def __init__(self):
        pass

    def connect(self, host, port):
        self.host = host
        self.port = port
        self.sock = socket.socket()
        self.sock.connect((host, port))
        self.sock.setblocking(0)

    def send(self, message):
        self.sock.send(message.serialize())

    def close(self):
        self.sock.close()

    def check(self, callback):
        message = self.sock.recv(10240)
        counter = 0

        while callback and message and len(message) > counter + 4:
            tag = struct.unpack('<HH', message[counter:counter + 4])[1]
            for subclass in Serializer.__subclasses__():
                if tag == subclass().tag:
                    callback(subclass().deserialize(message[counter:counter + subclass().size]))
                    counter += subclass().size
