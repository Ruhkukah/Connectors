#!/usr/bin/env python

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

import datetime
import time

from client import Client
from schema import *

c = Client()

c.connect("127.0.0.1", 2001)

e = Establish()

e.populate("KeepaliveInterval", 60000)
e.populate("Credentials", 'TEST')

print(str(datetime.datetime.now()) + " OUT: " + str(e.deserialize(e.serialize())))

c.send(e)

time.sleep(1)


def on(message):
    print(str(datetime.datetime.now()) + " IN: " + str(message))


c.check(on)

seq = Sequence()
seq.populate("NextSeqNo", 18446744073709551615)
print(str(datetime.datetime.now()) + " OUT: " + str(seq.deserialize(seq.serialize())))
c.send(seq)

nom = NewOrderSingle()
nom.populate("ClOrdID", 104)
nom.populate("Account", '5000061')
nom.populate("Price", 500000)  # please adjust the price accordingly to the chosen security
nom.populate("OrderQty", 3)
nom.populate("Side", 1)
nom.populate("TimeInForce", 0)
nom.populate("SecurityID", 240193)  # check that the security still exists
nom.populate("ExpireDate", 18446744073709551615)
nom.populate("ClOrdLinkID", 9494)
nom.populate("ClientFlags", 0)
nom.populate("ComplianceID", ' ')

print(str(datetime.datetime.now()) + " OUT: " + str(nom.deserialize(nom.serialize())))

c.send(nom)

time.sleep(1)

c.check(on)

time.sleep(10)

term = Terminate()
term.populate("TerminationCode", 0)

print(str(datetime.datetime.now()) + " OUT: " + str(term.deserialize(term.serialize())))
c.send(term)

time.sleep(1)

c.check(on)
