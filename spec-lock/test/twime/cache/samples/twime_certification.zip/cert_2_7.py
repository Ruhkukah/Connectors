#!/usr/bin/env python

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

import datetime
import time

from client import Client
from schema import *

c = Client()

c.connect("127.0.0.1", 2001)

e = Establish()

e.populate("KeepaliveInterval", 60000)
e.populate("Credentials", 'TEST')

print(str(datetime.datetime.now()) + " OUT: " + str(e.deserialize(e.serialize())))

c.send(e)

time.sleep(1)


def on(message):
    print(str(datetime.datetime.now()) + " IN: " + str(message))


c.check(on)

seq = Sequence()
seq.populate("NextSeqNo", 18446744073709551615)
print(str(datetime.datetime.now()) + " OUT: " + str(seq.deserialize(seq.serialize())))
c.send(seq)

omc = OrderMassCancelRequest()

omc.populate("ClOrdID", 105)
omc.populate("ClOrdLinkID", 55123)
omc.populate("Side", 89)
omc.populate("Account", '5000061')
omc.populate("SecurityGroup", '')
omc.populate("SecurityType", 0b001)  # bitmask for futures
omc.populate("SecurityID", 2147483647)  # check that the security still exists

print(str(datetime.datetime.now()) + " OUT: " + str(omc.deserialize(omc.serialize())))

c.send(omc)

time.sleep(1)

c.check(on)

omc2 = OrderMassCancelRequest()

omc2.populate("ClOrdID", 105)
omc2.populate("ClOrdLinkID", 55321)
omc2.populate("Side", 89)
omc2.populate("Account", '5000061')
omc2.populate("SecurityGroup", '')
omc2.populate("SecurityType", 0b010)  # bitmask for options
omc2.populate("SecurityID", 2147483647)

print(str(datetime.datetime.now()) + " OUT: " + str(omc2.deserialize(omc2.serialize())))

c.send(omc2)

time.sleep(1)

c.check(on)

omc3 = OrderMassCancelRequest()

omc3.populate("ClOrdID", 105)
omc3.populate("ClOrdLinkID", 55321)
omc3.populate("Side", 89)
omc3.populate("Account", '5000061')
omc3.populate("SecurityGroup", '')
omc3.populate("SecurityType", 0b100)  # bitmask for multilegs
omc3.populate("SecurityID", 2147483647)

print(str(datetime.datetime.now()) + " OUT: " + str(omc2.deserialize(omc2.serialize())))

c.send(omc3)

time.sleep(1)

c.check(on)

omc4 = OrderMassCancelRequest()

omc4.populate("ClOrdID", 105)
omc4.populate("ClOrdLinkID", 55321)
omc4.populate("Side", 89)
omc4.populate("Account", '5000061')
omc4.populate("SecurityGroup", '')
omc4.populate("SecurityType", 0b111)  # bitmask for futures, options and multilegs
omc4.populate("SecurityID", 2147483647)

print(str(datetime.datetime.now()) + " OUT: " + str(omc2.deserialize(omc2.serialize())))

c.send(omc4)

time.sleep(1)

c.check(on)

time.sleep(10)

term = Terminate()
term.populate("TerminationCode", 0)

print(str(datetime.datetime.now()) + " OUT: " + str(term.deserialize(term.serialize())))
c.send(term)

time.sleep(1)

c.check(on)
