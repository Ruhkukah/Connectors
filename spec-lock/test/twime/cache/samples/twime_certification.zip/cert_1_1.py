#!/usr/bin/env python

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

import datetime
import time

from client import Client
from schema import *

c = Client()

c.connect("127.0.0.1", 2001)

e = Establish()

e.populate("KeepaliveInterval", 10000)
e.populate("Credentials", 'TEST')

print(str(datetime.datetime.now()) + " OUT: " + str(e.deserialize(e.serialize())))

c.send(e)

time.sleep(1)


def on(message):
    print(str(datetime.datetime.now()) + " IN: " + str(message))


c.check(on)

seq = Sequence()
seq.populate("NextSeqNo", 18446744073709551615)
print(str(datetime.datetime.now()) + " OUT: " + str(seq.deserialize(seq.serialize())))
c.send(seq)

time.sleep(10)
print(str(datetime.datetime.now()) + " OUT: " + str(seq.deserialize(seq.serialize())))
c.send(seq)
time.sleep(10)
c.check(on)
time.sleep(10)
c.check(on)
