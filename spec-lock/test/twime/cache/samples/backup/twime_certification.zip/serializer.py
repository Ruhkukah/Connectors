#!/usr/bin/env python
import sys

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

from struct import Struct
from collections import namedtuple
from functools import partial


class Serializer(Struct):

    def __init__(self, tag, fields):
        self.tag = tag
        self.fields = fields

        fmt = '<'
        for f in self.fields: fmt += f['fmt']

        Struct.__init__(self, fmt)

        self.clean()
        self.header()

    def header(self):
        self.populate('blockLength', (self.size - 8))
        self.populate('templateId', self.tag)
        self.populate('schemaId', 19781)
        self.populate('version', 6)

    def clean(self):
        self.values = {}
        for f in self.fields:
            if 's' in f['fmt']:
                self.values[f['name']] = ''
            else:
                self.values[f['name']] = 0

    def deserialize(self, data):
        Class = namedtuple(self.__class__.__name__, [f["name"] for f in self.fields])
        return Class._make(self.unpack(data))

    def serialize(self):
        handler = self.pack
        for f in self.fields:
            handler = partial(handler, self.values[f['name']])

        return handler()

    def populate(self, name, value):
        field = {}
        for f in self.fields:
            if f['name'] == name:
                field = f

        if not field:
            raise Exception("Invalid field [" + name + "]")
        if sys.version_info >= (3, 3) and type(value) is str:
            value = value.encode("utf-8")
        self.values[name] = value
