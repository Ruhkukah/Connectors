#!/usr/bin/env python

__copyright__ = "Copyright 2023, Moscow Exchange"
__email__ = "help@moex.com"

import datetime
import time

from client import Client
from schema import *

c = Client()

c.connect("127.0.0.1", 2001)

e = Establish()

e.populate("KeepaliveInterval", 60000)
e.populate("Credentials", 'TEST')

print(str(datetime.datetime.now()) + " OUT: " + str(e.deserialize(e.serialize())))

c.send(e)

time.sleep(1)


def on(message):
    print(str(datetime.datetime.now()) + " IN: " + str(message))


c.check(on)

seq = Sequence()
seq.populate("NextSeqNo", 18446744073709551615)

print(str(datetime.datetime.now()) + " OUT: " + str(seq.deserialize(seq.serialize())))
c.send(seq)

nos = NewOrderIceberg()
nos.populate("ClOrdID", 111)
nos.populate("Account", '5000061')
nos.populate("Price", 3319100000)  # please adjust the price accordingly to the chosen security
nos.populate("OrderQty", 1000)
nos.populate("DisplayQty", 100)
nos.populate("DisplayVarianceQty", 2)
nos.populate("Side", 1)
nos.populate("SecurityID", 305203)  # check that the security still exists
nos.populate("ExpireDate", 1701392400000000000)  # check that the timestamp is correct
nos.populate("ClientFlags", 0)
nos.populate("ClOrdLinkID", 7895429)

print(str(datetime.datetime.now()) + " OUT: " + str(nos.deserialize(nos.serialize())))

c.send(nos)

time.sleep(1)
c.check(on)

time.sleep(10)

term = Terminate()
term.populate("TerminationCode", 0)

print(str(datetime.datetime.now()) + " OUT: " + str(term.deserialize(term.serialize())))
c.send(term)

time.sleep(1)

c.check(on)

time.sleep(1)
