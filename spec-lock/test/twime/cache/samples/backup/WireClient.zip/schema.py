#!/usr/bin/env python

__copyright__ = "Copyright 2020, Moscow Exchange"
__author__ = "Rishat Askarov"
__email__ = "help@moex.com"

from serializer import Serializer


class Establish(Serializer):

    def __init__(self):
        tag = 5000

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'KeepaliveInterval', 'fmt': 'L'},
            {'name': 'Credentials', 'fmt': '20s'}
        ]

        Serializer.__init__(self, tag, fields)


class EstablishmentAck(Serializer):

    def __init__(self):
        tag = 5001

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'RequestTimestamp', 'fmt': 'Q'},
            {'name': 'KeepaliveInterval', 'fmt': 'L'},
            {'name': 'NextSeqNo', 'fmt': 'Q'}
        ]

        Serializer.__init__(self, tag, fields)


class SystemEvent(Serializer):
    def __init__(self):
        tag = 7011

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'TradSesEvent', 'fmt': 'B'}

        ]

        Serializer.__init__(self, tag, fields)


class EstablishmentReject(Serializer):

    def __init__(self):
        tag = 5002

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'RequestTimestamp', 'fmt': 'Q'},
            {'name': 'EstablishmentRejectCode', 'fmt': 'B'}
        ]

        Serializer.__init__(self, tag, fields)


class Terminate(Serializer):

    def __init__(self):
        tag = 5003

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'TerminationCode', 'fmt': 'B'}
        ]

        Serializer.__init__(self, tag, fields)


class RetransmitRequest(Serializer):

    def __init__(self):
        tag = 5004

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'FromSeqNo', 'fmt': 'Q'},
            {'name': 'Count', 'fmt': 'I'}
        ]

        Serializer.__init__(self, tag, fields)


class Retransmission(Serializer):

    def __init__(self):
        tag = 5005

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'NextSeqNo', 'fmt': 'Q'},
            {'name': 'RequestTimestamp', 'fmt': 'Q'},
            {'name': 'Count', 'fmt': 'I'}
        ]

        Serializer.__init__(self, tag, fields)


class BusinessMessageReject(Serializer):

    def __init__(self):
        tag = 5009

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "RequestTimestamp", "fmt": "Q"},
            {"name": "OrdRejReason", "fmt": "i"},
        ]
        Serializer.__init__(self, tag, fields)

class Sequence(Serializer):

    def __init__(self):
        tag = 5006

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'NextSeqNo', 'fmt': 'Q'}
        ]

        Serializer.__init__(self, tag, fields)


class FloodReject(Serializer):

    def __init__(self):
        tag = 5007

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'QueueSize', 'fmt': 'I'},
            {'name': 'PenaltyRemain', 'fmt': 'I'}
        ]

        Serializer.__init__(self, tag, fields)


class SessionReject(Serializer):

    def __init__(self):
        tag = 5008

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'RefTagID', 'fmt': 'I'},
            {'name': 'SessionRejectReason', 'fmt': 'B'}
        ]

        Serializer.__init__(self, tag, fields)


class NewOrderSingle(Serializer):

    def __init__(self):
        tag = 6000

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'ExpireDate', 'fmt': 'Q'},
            {'name': 'Price', 'fmt': 'q'},
            {'name': 'SecurityID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TimeInForce', 'fmt': 'B'},
            {'name': 'Side', 'fmt': 'B'},
            {'name': 'ClientFlags', 'fmt': 'B'},
            {'name': 'Account', 'fmt': '7s'}
        ]

        Serializer.__init__(self, tag, fields)


class NewOrderSingleResponse(Serializer):

    def __init__(self):
        tag = 7000

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'ExpireDate', 'fmt': 'Q'},
            {'name': 'OrderID', 'fmt': 'q'},
            {'name': 'Flags', 'fmt': 'q'},
            {'name': 'Price', 'fmt': 'q'},
            {'name': 'SecurityID', 'fmt': 'i'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'},
            {'name': 'Side', 'fmt': 'B'}
        ]

        Serializer.__init__(self, tag, fields)


class NewOrderIceberg(Serializer):

    def __init__(self):
        tag = 6008

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "ExpireDate", "fmt": "Q"},
            {"name": "Price", "fmt": "q"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "ClOrdLinkID", "fmt": "i"},
            {"name": "DisplayQty", "fmt": "I"},
            {"name": "DisplayVarianceQty", "fmt": "I"},
            {"name": "OrderQty", "fmt": "I"},
            {"name": "Side", "fmt": "B"},
            {"name": "ClientFlags", "fmt": "B"},
            {"name": "Account", "fmt": "7s"},
        ]

        Serializer.__init__(self, tag, fields)


class NewOrderIcebergResponse(Serializer):

    def __init__(self):
        tag = 7013
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "Timestamp", "fmt": "Q"},
            {"name": "ExpireDate", "fmt": "Q"},
            {"name": "OrderID", "fmt": "q"},
            {"name": "DisplayOrderID", "fmt": "q"},
            {"name": "Flags", "fmt": "q"},
            {"name": "Price", "fmt": "q"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "OrderQty", "fmt": "I"},
            {"name": "DisplayQty", "fmt": "I"},
            {"name": "DisplayVarianceQty", "fmt": "I"},
            {"name": "TradingSessionID", "fmt": "i"},
            {"name": "ClOrdLinkID", "fmt": "i"},
            {"name": "Side", "fmt": "B"},
        ]
        Serializer.__init__(self, tag, fields)


class OrderIcebergCancelRequest(Serializer):

    def __init__(self):
        tag = 6009

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "OrderID", "fmt": "q"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "ClientFlags", "fmt": "B"},
            {"name": "Account", "fmt": "7s"},
        ]

        Serializer.__init__(self, tag, fields)


class OrderIcebergReplaceRequest(Serializer):

    def __init__(self):
        tag = 6010

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "OrderID", "fmt": "q"},
            {"name": "Price", "fmt": "q"},
            {"name": "ClOrdLinkID", "fmt": "i"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "ClientFlags", "fmt": "B"},
            {"name": "Account", "fmt": "7s"},
        ]

        Serializer.__init__(self, tag, fields)


class OrderCancelRequest(Serializer):

    def __init__(self):
        tag = 6006

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "OrderID", "fmt": "q"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "ClientFlags", "fmt": "B"},
            {"name": "Account", "fmt": "7s"},
        ]

        Serializer.__init__(self, tag, fields)

class OrderCancelResponse(Serializer):

    def __init__(self):
        tag = 7003

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'OrderID', 'fmt': 'q'},
            {'name': 'Flags', 'fmt': 'q'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'}

        ]

        Serializer.__init__(self, tag, fields)


class OrderReplaceRequest(Serializer):

    def __init__(self):
        tag = 6007

        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {"name": "ClOrdID", "fmt": "Q"},
            {"name": "OrderID", "fmt": "q"},
            {"name": "Price", "fmt": "q"},
            {"name": "OrderQty", "fmt": "I"},
            {"name": "ClOrdLinkID", "fmt": "i"},
            {"name": "SecurityID", "fmt": "i"},
            {"name": "Mode", "fmt": "B"},
            {"name": "ClientFlags", "fmt": "B"},
            {"name": "Account", "fmt": "7s"},
        ]

        Serializer.__init__(self, tag, fields)

class OrderMassCancelByBFLimitRequest(Serializer):

    def __init__(self):
        tag = 6005
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Account', 'fmt': '7s'}
        ]

        Serializer.__init__(self, tag, fields)


class OrderReplaceResponse(Serializer):
    def __init__(self):
        tag = 7005
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'OrderID', 'fmt': 'q'},
            {'name': 'PrevOrderID', 'fmt': 'q'},
            {'name': 'Flags', 'fmt': 'q'},
            {'name': 'Price', 'fmt': 'q'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'}

        ]

        Serializer.__init__(self, tag, fields)


class ExecutionSingleReport(Serializer):
    def __init__(self):
        tag = 7008
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'OrderID', 'fmt': 'q'},
            {'name': 'TrdMatchID', 'fmt': 'q'},
            {'name': 'Flags', 'fmt': 'q'},
            {'name': 'LastPx', 'fmt': 'q'},
            {'name': 'LastQty', 'fmt': 'I'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'},
            {'name': 'SecurityID', 'fmt': 'i'},
            {'name': 'Side', 'fmt': 'B'}

        ]

        Serializer.__init__(self, tag, fields)


class ExecutionMultilegReport(Serializer):
    def __init__(self):
        tag = 7009
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'OrderID', 'fmt': 'q'},
            {'name': 'TrdMatchID', 'fmt': 'q'},
            {'name': 'Flags', 'fmt': 'q'},
            {'name': 'LastPx', 'fmt': 'q'},
            {'name': 'LegPrice', 'fmt': 'q'},
            {'name': 'LastQty', 'fmt': 'I'},
            {'name': 'OrderQty', 'fmt': 'I'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'},
            {'name': 'SecurityID', 'fmt': 'i'},
            {'name': 'Side', 'fmt': 'B'}

        ]

        Serializer.__init__(self, tag, fields)


class OrderMassCancelRequest(Serializer):
    def __init__(self):
        tag = 6004
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'ClOrdLinkID', 'fmt': 'i'},
            {'name': 'SecurityID', 'fmt': 'i'},
            {'name': 'SecurityType', 'fmt': 'B'},
            {'name': 'Side', 'fmt': 'B'},
            {'name': 'Account', 'fmt': '7s'},
            {'name': 'SecurityGroup', 'fmt': '25s'}

        ]

        Serializer.__init__(self, tag, fields)


class OrderMassCancelResponse(Serializer):
    def __init__(self):
        tag = 7007
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'ClOrdID', 'fmt': 'Q'},
            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'TotalAffectedOrders', 'fmt': 'i'}
        ]
        Serializer.__init__(self, tag, fields)


class EmptyBook(Serializer):
    def __init__(self):
        tag = 7010
        fields = [
            {'name': 'blockLength', 'fmt': 'H'},
            {'name': 'templateId', 'fmt': 'H'},
            {'name': 'schemaId', 'fmt': 'H'},
            {'name': 'version', 'fmt': 'H'},

            {'name': 'Timestamp', 'fmt': 'Q'},
            {'name': 'TradingSessionID', 'fmt': 'i'},
        ]
        Serializer.__init__(self, tag, fields)
