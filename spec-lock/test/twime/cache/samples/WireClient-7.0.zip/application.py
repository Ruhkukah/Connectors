#!/usr/bin/env python

__copyright__ = "Copyright 2024, Moscow Exchange"
__author__ =    "Nikolay Viskov"
__email__ =     "help@moex.com"

from client import Client
from schema import *

import time

# test case 1, connect to gate and send order with invalid enum value
c = Client()

c.connect("127.0.0.1", 2222)

e = Establish()

e.populate("KeepaliveInterval", 1000)
e.populate("Credentials", "BBBBBB")

print(e.deserialize(e.serialize()))

c.send(e)

nos = NewOrderSingle()
nos.populate("ClOrdID", 123456)
nos.populate("ExpireDate", 18446744073709551615)
nos.populate("Side", 9)

print(nos.deserialize(nos.serialize()))

c.send(nos)

def on(message):
    print (message)

time.sleep(1)

c.check(on)

c.close()



# test case 2, try to establish connection with invalid KeepaliveInterval
c = Client()

c.connect("127.0.0.1", 2222)

e = Establish()

e.populate("KeepaliveInterval", 10)
e.populate("Credentials", "BBBBBB")

print(e.deserialize(e.serialize()))

c.send(e)

time.sleep(1)

c.check(on)


# test case 3, connect to gate and wait for disconnect due to missing heartbeat
c = Client()

c.connect("127.0.0.1", 2222)

e = Establish()

e.populate("KeepaliveInterval", 1000)
e.populate("Credentials", "BBBBBB")

print(e.deserialize(e.serialize()))

c.send(e)

time.sleep(3)

c.check(on)

c.close()
