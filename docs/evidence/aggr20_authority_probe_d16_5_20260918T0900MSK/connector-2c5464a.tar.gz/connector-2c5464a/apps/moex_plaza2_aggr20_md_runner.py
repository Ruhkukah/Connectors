#!/usr/bin/env python3
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

from moex_phase0_common import load_json_yaml


def _find_runner() -> Path:
    candidates = [
        Path.cwd() / "apps" / "moex_plaza2_aggr20_md_test_runner",
        Path.cwd() / "build-docker-linux" / "apps" / "moex_plaza2_aggr20_md_test_runner",
        Path.cwd() / "build" / "apps" / "moex_plaza2_aggr20_md_test_runner",
        Path(__file__).resolve().parents[1] / "build-docker-linux" / "apps" / "moex_plaza2_aggr20_md_test_runner",
        Path(__file__).resolve().parents[1] / "build" / "apps" / "moex_plaza2_aggr20_md_test_runner",
    ]
    runner = next((path for path in candidates if path.exists()), None)
    if runner is None:
        raise SystemExit("missing built moex_plaza2_aggr20_md_test_runner executable")
    return runner


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the Phase 5D PLAZA II AGGR20 TEST bring-up wrapper.")
    parser.add_argument("--profile", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--armed-test-network", action="store_true")
    parser.add_argument("--armed-test-session", action="store_true")
    parser.add_argument("--armed-test-plaza2", action="store_true")
    parser.add_argument("--armed-test-market-data", action="store_true")
    parser.add_argument("--credentials-env")
    parser.add_argument("--credentials-file")
    parser.add_argument("--software-key-env")
    parser.add_argument("--software-key-file")
    parser.add_argument("--clock-evidence-file")
    parser.add_argument("--max-polls", type=int, default=8)
    args = parser.parse_args()

    profile_path = Path(args.profile).resolve()
    profile = load_json_yaml(profile_path)
    plaza2_md = profile.get("plaza2_aggr20_md_test") or {}
    if not plaza2_md:
        raise SystemExit("profile does not contain a plaza2_aggr20_md_test section")

    runtime = plaza2_md.get("runtime") or {}
    session = plaza2_md.get("session") or {}
    credentials = plaza2_md.get("credentials") or {}
    software_key = plaza2_md.get("software_key") or {}
    endpoint = plaza2_md.get("endpoint") or {}
    stream = plaza2_md.get("stream") or {}

    command = [
        str(_find_runner()),
        "--profile-id",
        str(profile.get("profile_id", profile_path.stem)),
        "--output-dir",
        str(Path(args.output_dir).resolve()),
        "--endpoint-host",
        str(endpoint.get("host", "")),
        "--endpoint-port",
        str(endpoint.get("port", 0)),
        "--runtime-root",
        str(runtime.get("root", "")),
        "--env-open-settings",
        str(runtime.get("env_open_settings", "")),
        "--connection-settings",
        str(session.get("connection_settings", "")),
        "--stream-settings",
        str(stream.get("settings", "")),
        "--process-timeout-ms",
        str(session.get("process_timeout_ms", 50)),
        "--credentials-source",
        str(credentials.get("source", "none")),
        "--max-polls",
        str(args.max_polls),
    ]

    for option, key in (
        ("--library-path", "library_path"),
        ("--scheme-dir", "scheme_dir"),
        ("--config-dir", "config_dir"),
        ("--expected-spectra-release", "expected_spectra_release"),
        ("--expected-runtime-library-sha256", "expected_runtime_library_sha256"),
        ("--expected-scheme-sha256", "expected_scheme_sha256"),
    ):
        value = str(runtime.get(key, ""))
        if value:
            command.extend([option, value])

    connection_open_settings = str(session.get("connection_open_settings", ""))
    if connection_open_settings:
        command.extend(["--connection-open-settings", connection_open_settings])
    stream_open_settings = str(stream.get("open_settings", ""))
    if stream_open_settings:
        command.extend(["--stream-open-settings", stream_open_settings])

    env_var = args.credentials_env or str(credentials.get("env_var", ""))
    file_path = args.credentials_file or str(credentials.get("credentials_file", credentials.get("file_path", "")))
    if env_var:
        command.extend(["--credentials-env-var", env_var])
    if file_path:
        command.extend(["--credentials-file", file_path])

    software_key_source = str(software_key.get("source", "none"))
    command.extend(["--software-key-source", software_key_source])
    software_key_env = args.software_key_env or str(software_key.get("env_var", ""))
    software_key_file = args.software_key_file or str(
        software_key.get("credentials_file", software_key.get("file_path", ""))
    )
    if software_key_env:
        command.extend(["--software-key-env-var", software_key_env])
    if software_key_file:
        command.extend(["--software-key-file", software_key_file])

    clock_evidence_file = args.clock_evidence_file or str(plaza2_md.get("clock_evidence_file", ""))
    if clock_evidence_file:
        command.extend(["--clock-evidence-file", clock_evidence_file])

    if args.armed_test_network:
        command.append("--armed-test-network")
    if args.armed_test_session:
        command.append("--armed-test-session")
    if args.armed_test_plaza2:
        command.append("--armed-test-plaza2")
    if args.armed_test_market_data:
        command.append("--armed-test-market-data")

    subprocess.run(command, check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
