#pragma once

#include "plaza2_generated_metadata.hpp"

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace moex::plaza2::cgate {

enum class Plaza2Environment : std::uint8_t {
    Test = 0,
    Prod = 1,
};

enum class Plaza2Compatibility : std::uint8_t {
    Unknown = 0,
    Compatible = 1,
    CompatibleWithWarnings = 2,
    Incompatible = 3,
};

enum class Plaza2ErrorCode : std::uint16_t {
    None = 0,
    InvalidConfiguration,
    MissingRuntime,
    SymbolLoadFailed,
    AdapterState,
    RuntimeCallFailed,
    DecodeFailed,
    CallbackFailed,
    ProbeIncompatible,
    UnknownRuntimeResult,
    SendDisabledPreSendPhase,
};

enum class Plaza2ProbeIssueCode : std::uint16_t {
    MissingRuntimeRoot = 0,
    MissingLibrary,
    MissingSchemeDirectory,
    MissingSchemeFile,
    MissingConfigDirectory,
    MissingConfigFile,
    UnexpectedConfigFile,
    UnsupportedLayout,
    UnsupportedVersion,
    MissingSymbol,
    FileHashMismatch,
    RuntimeSchemeParseFailed,
    ReviewedTableMissing,
    ReviewedTableSignatureMismatch,
    RuntimeTableUnexpected,
};

struct Plaza2Error {
    Plaza2ErrorCode code{Plaza2ErrorCode::None};
    std::uint32_t runtime_code{0};
    std::string message;

    [[nodiscard]] explicit operator bool() const noexcept {
        return code != Plaza2ErrorCode::None;
    }
};

struct Plaza2ProbeIssue {
    Plaza2ProbeIssueCode code{Plaza2ProbeIssueCode::MissingRuntimeRoot};
    bool fatal{false};
    std::string subject;
    std::string message;
};

struct Plaza2VersionMarkers {
    std::string spectra_release;
    std::string dds_version;
    std::string target_polygon;
};

class Plaza2QualificationObserver;

struct Plaza2Settings {
    Plaza2Environment environment{Plaza2Environment::Test};
    std::filesystem::path runtime_root;
    std::filesystem::path library_path;
    std::filesystem::path scheme_dir;
    std::filesystem::path config_dir;
    std::string env_open_settings;
    std::string application_name_prefix{"connectors"};
    std::string application_name_scope{"plaza2"};
    std::uint32_t application_instance{0};
    std::string expected_spectra_release;
    std::string expected_runtime_library_sha256;
    std::string expected_scheme_sha256;
    // Optional qualification sink. Owner outlives Env; callbacks must not throw or call CGate.
    Plaza2QualificationObserver* qualification_observer{nullptr};
};

struct Plaza2RuntimeLayout {
    std::filesystem::path runtime_root;
    std::filesystem::path library_path;
    std::filesystem::path scheme_dir;
    std::filesystem::path scheme_path;
    std::filesystem::path config_dir;
    Plaza2VersionMarkers version_markers;
    std::vector<std::string> expected_config_files;
    std::vector<std::string> present_config_files;
};

struct Plaza2SchemeDriftReport {
    Plaza2Compatibility compatibility{Plaza2Compatibility::Unknown};
    std::string runtime_scheme_sha256;
    std::size_t reviewed_table_count{0};
    std::size_t runtime_table_count{0};
    std::size_t reviewed_field_count{0};
    std::size_t runtime_field_count{0};
    std::size_t fatal_drift_count{0};
    std::size_t warning_drift_count{0};
    std::vector<std::string> fatal_drift_tables;
    std::vector<std::string> warning_drift_tables;
    std::string last_fatal_drift_reason;
    std::string last_warning_drift_reason;
    std::vector<Plaza2ProbeIssue> issues;
};

struct Plaza2RuntimeProbeReport {
    Plaza2Compatibility compatibility{Plaza2Compatibility::Unknown};
    Plaza2RuntimeLayout layout;
    Plaza2SchemeDriftReport scheme_drift;
    std::string runtime_version;
    std::string runtime_library_sha256;
    std::vector<std::string> resolved_symbols;
    std::vector<Plaza2ProbeIssue> issues;
    bool runtime_root_present{false};
    bool runtime_library_present{false};
    bool runtime_library_loadable{false};
    // V1 fake/offline transport boundary.  This is deliberately a symbol
    // exported only by the test CGate DSO; a compatible real runtime must not
    // satisfy the TEST transport host.
    bool fake_runtime_marker_present{false};
    bool runtime_identity_recognized{false};
    bool trading_capable{false};
    bool scheme_file_present{false};
    bool config_dir_present{false};
    std::vector<std::string> missing_trading_symbols;
};

enum class Plaza2DecodedValueKind : std::uint8_t {
    None = 0,
    SignedInteger = 1,
    UnsignedInteger = 2,
    Decimal = 3,
    FloatingPoint = 4,
    String = 5,
    Timestamp = 6,
};

enum class Plaza2ListenerEventKind : std::uint8_t {
    Open = 0,
    Close = 1,
    TransactionBegin = 2,
    TransactionCommit = 3,
    StreamData = 4,
    Online = 5,
    LifeNum = 6,
    ClearDeleted = 7,
    ReplState = 8,
    Timeout = 9,
};

inline constexpr generated::StreamCode kNoStreamCode = static_cast<generated::StreamCode>(0);
inline constexpr generated::TableCode kNoTableCode = static_cast<generated::TableCode>(0);
inline constexpr generated::FieldCode kNoFieldCode = static_cast<generated::FieldCode>(0);

struct Plaza2DecodedFieldValue {
    generated::FieldCode field_code{kNoFieldCode};
    Plaza2DecodedValueKind kind{Plaza2DecodedValueKind::None};
    std::int64_t signed_value{0};
    std::uint64_t unsigned_value{0};
    std::string_view text_value{};
    // The runtime-owned field bytes are valid only for the duration of the
    // callback. They preserve the exact vendor representation for bounded
    // diagnostics and exact decimal consumers.
    std::span<const std::byte> raw_value{};
    std::string_view type_token{};
    std::int64_t decimal_mantissa{0};
    std::int32_t decimal_scale{0};
    bool decimal_exact{false};
};

struct Plaza2ListenerEvent {
    Plaza2ListenerEventKind kind{Plaza2ListenerEventKind::Open};
    generated::StreamCode stream_code{kNoStreamCode};
    generated::TableCode table_code{kNoTableCode};
    std::span<const Plaza2DecodedFieldValue> fields{};
    std::int32_t message_id{0};
    std::string_view message_name{};
    std::uint32_t user_id{0};
    std::span<const std::byte> raw_payload{};
    std::uint64_t unsigned_value{0};
    std::int64_t signed_value{0};
    std::string_view text_value{};
    std::uint32_t clear_deleted_flags{0};
    std::uint32_t close_reason{0};
    std::span<const std::uint8_t> raw_nulls{};
    std::size_t table_index{0};
};

struct Plaza2ForensicField {
    std::string name, type, generic_value, independent_value;
    std::size_t offset{}, size{}, ordinal{};
    bool is_null{}, equal{};
    std::uint32_t conversion_result{};
};
struct Plaza2ForensicRow {
    generated::StreamCode stream_code{kNoStreamCode};
    generated::TableCode table_code{kNoTableCode};
    std::size_t table_index{}, message_size{};
    std::string message_name;
    std::vector<std::byte> payload;
    std::vector<std::uint8_t> nulls;
    std::vector<Plaza2ForensicField> fields;
};

class Plaza2QualificationObserver {
  public:
    virtual ~Plaza2QualificationObserver() = default;
    virtual void observe(const Plaza2ListenerEvent&, const Plaza2Error&) noexcept = 0;
    [[nodiscard]] virtual bool wants_forensic_row(const Plaza2ListenerEvent&) const noexcept {
        return false;
    }
    virtual void forensic_row(Plaza2ForensicRow) noexcept {}
    // object: 10 connection, 11 publisher, 12 listener; stream zero for reply.
    virtual void runtime_state(std::uint32_t, std::uint32_t, std::uint32_t, std::uint32_t) noexcept {}
};

class Plaza2ListenerEventHandler {
  public:
    virtual ~Plaza2ListenerEventHandler() = default;
    virtual void on_plaza2_listener_error(const Plaza2Error&) noexcept {}
    // Opt in only for an exact, completely qualified public wire scheme.
    [[nodiscard]] virtual bool wants_raw_replication() const noexcept {
        return false;
    }
    [[nodiscard]] virtual Plaza2Error on_plaza2_listener_event(const Plaza2ListenerEvent& event) = 0;
};

[[nodiscard]] Plaza2Error validate_plaza2_settings(const Plaza2Settings& settings);
[[nodiscard]] std::string_view plaza2_compatibility_name(Plaza2Compatibility compatibility) noexcept;
[[nodiscard]] std::string make_plaza2_application_name(std::string_view prefix, std::string_view scope,
                                                       std::uint32_t instance);
[[nodiscard]] Plaza2Error translate_plaza2_result(std::string_view operation, std::uint32_t runtime_code);
[[nodiscard]] std::string plaza2_sha256_hex(std::span<const std::byte> bytes);
[[nodiscard]] std::string plaza2_sha256_hex(std::string_view text);

class Plaza2RuntimeProbe {
  public:
    [[nodiscard]] static Plaza2RuntimeProbeReport probe(const Plaza2Settings& settings);
    [[nodiscard]] static std::span<const std::string_view> expected_config_filenames(Plaza2Environment environment);
    [[nodiscard]] static std::span<const std::string_view> required_runtime_symbols();
    [[nodiscard]] static std::span<const std::string_view> required_trading_symbols();
};

struct Plaza2RuntimeSharedState;
struct Plaza2ListenerCallbackState;

class Plaza2Env {
  public:
    Plaza2Env() = default;
    ~Plaza2Env();

    Plaza2Env(Plaza2Env&&) noexcept = default;
    Plaza2Env& operator=(Plaza2Env&&) noexcept = default;

    Plaza2Env(const Plaza2Env&) = delete;
    Plaza2Env& operator=(const Plaza2Env&) = delete;

    [[nodiscard]] Plaza2Error open(const Plaza2Settings& settings);
    [[nodiscard]] Plaza2Error close();
    [[nodiscard]] bool is_open() const noexcept;

  private:
    friend class Plaza2Connection;

    std::shared_ptr<Plaza2RuntimeSharedState> shared_;
    bool open_{false};
};

class Plaza2Connection {
  public:
    Plaza2Connection() = default;
    ~Plaza2Connection();

    Plaza2Connection(Plaza2Connection&&) noexcept = default;
    Plaza2Connection& operator=(Plaza2Connection&&) noexcept = default;

    Plaza2Connection(const Plaza2Connection&) = delete;
    Plaza2Connection& operator=(const Plaza2Connection&) = delete;

    [[nodiscard]] Plaza2Error create(Plaza2Env& env, std::string_view settings);
    [[nodiscard]] Plaza2Error open(std::string_view settings);
    [[nodiscard]] Plaza2Error process(std::uint32_t timeout_ms, std::uint32_t* runtime_code = nullptr);
    [[nodiscard]] Plaza2Error close();
    [[nodiscard]] Plaza2Error destroy();
    [[nodiscard]] Plaza2Error state(std::uint32_t& out_state) const;
    [[nodiscard]] bool is_created() const noexcept;

  private:
    friend class Plaza2Listener;
    friend class Plaza2Publisher;

    std::shared_ptr<Plaza2RuntimeSharedState> shared_;
    void* handle_{nullptr};
};

class Plaza2Listener {
  public:
    Plaza2Listener();
    ~Plaza2Listener();

    Plaza2Listener(Plaza2Listener&&) noexcept;
    Plaza2Listener& operator=(Plaza2Listener&&) noexcept;

    Plaza2Listener(const Plaza2Listener&) = delete;
    Plaza2Listener& operator=(const Plaza2Listener&) = delete;

    [[nodiscard]] Plaza2Error create(Plaza2Connection& connection, std::string_view settings);
    [[nodiscard]] Plaza2Error create(Plaza2Connection& connection, generated::StreamCode stream_code,
                                     std::string_view settings, Plaza2ListenerEventHandler* handler);
    [[nodiscard]] Plaza2Error open(std::string_view settings);
    [[nodiscard]] Plaza2Error close();
    [[nodiscard]] Plaza2Error destroy();
    [[nodiscard]] Plaza2Error state(std::uint32_t& out_state) const;
    [[nodiscard]] bool is_created() const noexcept;
    [[nodiscard]] const Plaza2Error& last_callback_error() const noexcept;

  private:
    std::shared_ptr<Plaza2RuntimeSharedState> shared_;
    void* handle_{nullptr};
    std::unique_ptr<Plaza2ListenerCallbackState> callback_state_;
};

enum class Plaza2SubmissionCertainty : std::uint8_t {
    DefinitelyNotSent = 0,
    PossiblySent = 1,
    Posted = 2,
};

struct Plaza2PublisherMessageResult {
    Plaza2SubmissionCertainty certainty{Plaza2SubmissionCertainty::DefinitelyNotSent};
    Plaza2Error validation_error;
    Plaza2Error allocation_error;
    Plaza2Error post_error;
    Plaza2Error free_error;
    std::size_t runtime_payload_size{0};
    bool post_invoked{false};
};

struct Plaza2PublisherCallCounts {
    std::uint64_t msgnew{0};
    std::uint64_t post{0};
};

class Plaza2Publisher {
  public:
    Plaza2Publisher() = default;
    ~Plaza2Publisher();

    Plaza2Publisher(Plaza2Publisher&&) noexcept = default;
    Plaza2Publisher& operator=(Plaza2Publisher&&) noexcept = default;

    Plaza2Publisher(const Plaza2Publisher&) = delete;
    Plaza2Publisher& operator=(const Plaza2Publisher&) = delete;

    [[nodiscard]] Plaza2Error create(Plaza2Connection& connection, std::string_view settings);
    [[nodiscard]] Plaza2Error open(std::string_view settings);
    [[nodiscard]] Plaza2PublisherMessageResult post_by_message_name(std::string_view message_name,
                                                                    std::span<const std::byte> payload,
                                                                    std::uint32_t user_id, bool need_reply);
    [[nodiscard]] Plaza2PublisherCallCounts call_counts() const noexcept {
        return call_counts_;
    }
    [[nodiscard]] Plaza2Error close();
    [[nodiscard]] Plaza2Error destroy();
    [[nodiscard]] Plaza2Error state(std::uint32_t& out_state) const;
    [[nodiscard]] bool is_created() const noexcept;

  private:
    Plaza2PublisherCallCounts call_counts_;
    std::shared_ptr<Plaza2RuntimeSharedState> shared_;
    void* handle_{nullptr};
};

} // namespace moex::plaza2::cgate
