#pragma once

#include "moex/plaza2/cgate/plaza2_fake_engine.hpp"

#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace moex::plaza2::private_state {

enum class InstrumentKind : std::uint8_t {
    kUnknown = 0,
    kFuture = 1,
    kOption = 2,
    kMultileg = 3,
};

enum class PositionScope : std::uint8_t {
    kClient = 0,
    kSettlementAccount = 1,
};

struct ConnectorHealthSnapshot {
    bool open{false};
    bool closed{false};
    bool snapshot_active{false};
    bool online{false};
    bool transaction_open{false};
    std::uint64_t commit_count{0};
    std::uint64_t callback_error_count{0};
};

struct ResumeMarkersSnapshot {
    bool has_lifenum{false};
    std::uint64_t last_lifenum{0};
    std::string last_replstate;
};

struct StreamHealthSnapshot {
    generated::StreamCode stream_code{fake::kNoStreamCode};
    std::string stream_name;
    bool online{false};
    bool snapshot_complete{false};
    std::uint64_t clear_deleted_count{0};
    std::uint64_t committed_row_count{0};
    std::uint64_t last_commit_sequence{0};
    bool has_publication_state{false};
    std::int32_t publication_state{0};
    std::int64_t last_trades_rev{0};
    std::int64_t last_trades_lifenum{0};
    std::int64_t last_server_time{0};
    std::int64_t last_info_moment{0};
    std::int64_t last_event_id{0};
    std::int32_t last_event_type{0};
    std::string last_message;
    // USERORDERBOOK periodic consistency is distinct from initial ONLINE.
    // It is established only by a committed regular info publication_state=1 row.
    bool periodic_snapshot_consistent{false};
};

// Exchange-native provenance for one committed source row.  repl_rev is
// meaningful only within lifenum; callers must retain both values when
// recording a readiness or execution-safety receipt.
struct SourceRowProvenance {
    generated::StreamCode stream_code{fake::kNoStreamCode};
    generated::TableCode table_code{fake::kNoTableCode};
    std::int64_t repl_rev{0};
    std::uint64_t lifenum{0};
    bool present{false};

    bool operator==(const SourceRowProvenance&) const = default;
};

// Exact scale-5 values for the negotiated futures session decimal fields.
struct SessionDecimal {
    std::int64_t units{0};
    static constexpr std::int64_t scale = 100000;
    bool operator==(const SessionDecimal&) const = default;
};
[[nodiscard]] std::optional<SessionDecimal> parse_session_decimal(std::string_view text) noexcept;

struct FuturePriceBounds {
    std::optional<SessionDecimal> lower;
    std::optional<SessionDecimal> upper;
    bool formula_confirmed{true};
    // Arithmetic validity only: never substitutes for transport/account/order gates.
    bool interval_valid{false};
    bool operator==(const FuturePriceBounds&) const = default;
};

struct FutureSessionTerms {
    std::int32_t isin_id{0};
    std::int32_t sess_id{0};
    std::optional<SessionDecimal> settlement_price;
    std::optional<SessionDecimal> raw_limit_up;
    std::optional<SessionDecimal> raw_limit_down;
    std::optional<SessionDecimal> min_step;
    std::int64_t repl_id{0};
    SourceRowProvenance source;
    FuturePriceBounds bounds;
    bool operator==(const FutureSessionTerms&) const = default;
};
[[nodiscard]] FuturePriceBounds evaluate_future_price_bounds(const FutureSessionTerms& terms) noexcept;

struct TradingSessionSnapshot {
    std::int32_t sess_id{0};
    std::int64_t begin{0};
    std::int64_t end{0};
    std::int32_t state{0};
    bool has_current_status{false};
    std::int32_t current_status{0};
    // SPECTRA93 compatibility shadows. SPECTRA9.9 removed these fields;
    // readiness, session terms and order gates never consume them.
    std::int64_t inter_cl_begin{0};
    std::int64_t inter_cl_end{0};
    std::int32_t inter_cl_state{0};
    bool eve_on{false};
    std::int64_t eve_begin{0};
    std::int64_t eve_end{0};
    bool mon_on{false};
    std::int64_t mon_begin{0};
    std::int64_t mon_end{0};
    std::int64_t settl_sess_begin{0};
    std::int64_t clr_sess_begin{0};
    std::int64_t settl_price_calc_time{0};
    std::int64_t settl_sess_t1_begin{0};
    std::int64_t margin_call_fix_schedule{0};
};

struct InstrumentLegSnapshot {
    std::int32_t leg_isin_id{0};
    std::int32_t qty_ratio{0};
    std::int8_t leg_order_no{0};
};

struct InstrumentSnapshot {
    std::int32_t isin_id{0};
    std::int32_t sess_id{0};
    InstrumentKind kind{InstrumentKind::kUnknown};
    std::string isin;
    std::string short_isin;
    std::string name;
    std::string base_contract_code;
    std::int32_t fut_isin_id{0};
    std::int32_t option_series_id{0};
    std::int32_t inst_term{0};
    std::int32_t roundto{0};
    std::int32_t lot_volume{0};
    std::int32_t trade_mode_id{0};
    std::int32_t state{0};
    bool current_session_member{false};
    std::int32_t current_session_state{0};
    bool has_current_status{false};
    std::int32_t current_status{0};
    std::int32_t signs{0};
    bool put{false};
    bool is_spread{false};
    std::string min_step;
    std::string step_price;
    std::string settlement_price;
    std::string strike;
    std::int64_t last_trade_date{0};
    std::int64_t group_mask{0};
    std::int64_t trade_period_access{0};
    std::vector<InstrumentLegSnapshot> legs;
    // Coherent fut_sess_contents row; never populated from fut_instruments.
    std::optional<FutureSessionTerms> future_session_terms;
};

struct MatchingMapSnapshot {
    std::int32_t base_contract_id{0};
    std::int8_t matching_id{0};
};

// Exchange-native REFDATA system message.  These rows are informational and
// must never be allowed to affect readiness when malformed or absent, but the
// complete committed payload is retained for operator/certification evidence.
struct SystemMessageSnapshot {
    std::int64_t repl_id{0};
    std::int64_t repl_rev{0};
    std::int8_t repl_act{0};
    std::int32_t msg_id{0};
    std::string lang_code;
    std::int32_t type_id{0};
    std::int64_t moment{0};
    std::string text;
    std::int8_t urgency{0};
    std::int8_t status{0};
    std::string message_body;
    SourceRowProvenance source;
    bool operator==(const SystemMessageSnapshot&) const = default;
};

enum class LimitParticipantKind : std::uint8_t { Unknown, BrokerageFirm, Client };
[[nodiscard]] LimitParticipantKind classify_limit_participant(std::string_view code) noexcept;

struct LimitSnapshot {
    LimitParticipantKind participant_kind{LimitParticipantKind::Unknown};
    std::int64_t repl_id{0};
    std::string account_code;
    bool limits_set{false};
    bool is_auto_update_limit{false};
    std::string money_free;
    std::string money_blocked;
    std::string vm_reserve;
    std::string fee;
    std::string money_old;
    std::string money_amount;
    std::string money_pledge_amount;
    std::string actual_amount_of_base_currency;
    // SPECTRA93 compatibility shadows. SPECTRA9.9 removed these fields;
    // participant identity, limits_set and money checks never consume them.
    std::string vm_intercl;
    std::string broker_fee;
    std::string penalty;
    std::string premium_intercl;
    std::string net_option_value;
};

// Borrowed committed map row; invalidated by the next mutation. Ambiguity never yields a row.
struct LimitLookup {
    std::size_t match_count{0};
    const LimitSnapshot* exact{nullptr};
};

struct PositionSnapshot {
    PositionScope scope{PositionScope::kClient};
    std::string account_code;
    std::int32_t isin_id{0};
    std::int8_t account_type{0};
    std::int64_t xpos{0};
    std::int64_t xbuys_qty{0};
    std::int64_t xsells_qty{0};
    std::int64_t xday_open_qty{0};
    std::int64_t xday_open_buys_qty{0};
    std::int64_t xday_open_sells_qty{0};
    std::int64_t xopen_qty{0};
    std::string waprice;
    std::string net_volume_rur;
    std::int64_t last_deal_id{0};
    std::int64_t last_quantity{0};
};

struct OwnOrderSnapshot {
    // TRADE and USERORDERBOOK are independent MOEX TEST evidence surfaces.
    // A snapshot is never a cross-stream merge: the source flags identify the
    // surface that supplied this row (regular/current-day are one
    // USERORDERBOOK surface).
    bool multileg{false};
    std::int64_t public_order_id{0};
    std::int64_t private_order_id{0};
    std::int32_t sess_id{0};
    std::int32_t isin_id{0};
    std::string client_code;
    std::string login_from;
    std::string comment;
    std::string price;
    std::int64_t public_amount{0};
    std::int64_t public_amount_rest{0};
    std::int64_t private_amount{0};
    std::int64_t private_amount_rest{0};
    std::int64_t id_deal{0};
    std::int64_t xstatus{0};
    std::int64_t xstatus2{0};
    std::int8_t dir{0};
    std::int8_t public_action{0};
    std::int8_t private_action{0};
    std::int64_t moment{0};
    std::uint64_t moment_ns{0};
    std::int32_t ext_id{0};
    std::vector<std::int64_t> public_order_id_aliases;
    std::vector<std::int64_t> private_order_id_aliases;
    bool identity_conflict{false};
    bool from_trade_repl{false};
    bool from_user_book{false};
    bool from_current_day{false};
    std::uint64_t trade_repl_commit_sequence{0};
    std::uint64_t user_orderbook_commit_sequence{0};
};

struct OwnTradeSnapshot {
    bool multileg{false};
    std::int64_t id_deal{0};
    std::int32_t sess_id{0};
    std::int32_t isin_id{0};
    std::string price;
    std::string rate_price;
    std::string swap_price;
    std::int64_t amount{0};
    std::int64_t public_order_id_buy{0};
    std::int64_t public_order_id_sell{0};
    std::int64_t private_order_id_buy{0};
    std::int64_t private_order_id_sell{0};
    std::int32_t ext_id_buy{0};
    std::int32_t ext_id_sell{0};
    std::string code_buy;
    std::string code_sell;
    std::string comment_buy;
    std::string comment_sell;
    std::string login_buy;
    std::string login_sell;
    std::int64_t moment{0};
    std::uint64_t moment_ns{0};
};

class Plaza2PrivateStateProjector final : public fake::CommitListener {
  public:
    Plaza2PrivateStateProjector();
    ~Plaza2PrivateStateProjector() override;

    Plaza2PrivateStateProjector(const Plaza2PrivateStateProjector&) = delete;
    Plaza2PrivateStateProjector& operator=(const Plaza2PrivateStateProjector&) = delete;
    Plaza2PrivateStateProjector(Plaza2PrivateStateProjector&&) noexcept;
    Plaza2PrivateStateProjector& operator=(Plaza2PrivateStateProjector&&) noexcept;

    [[nodiscard]] Plaza2PrivateStateProjector clone() const;

    void reset();

    [[nodiscard]] const ConnectorHealthSnapshot& connector_health() const;
    [[nodiscard]] const ResumeMarkersSnapshot& resume_markers() const;
    [[nodiscard]] std::span<const StreamHealthSnapshot> stream_health() const;
    [[nodiscard]] std::span<const TradingSessionSnapshot> sessions() const;
    [[nodiscard]] std::span<const InstrumentSnapshot> instruments() const;
    [[nodiscard]] std::optional<FutureSessionTerms> find_future_session_terms(std::int32_t isin_id) const;
    // Current-session indexed view. Empty for other sessions, missing/deleted rows or
    // another LifeNum. Committed source validity is distinct from live transport health.
    [[nodiscard]] std::optional<FutureSessionTerms>
    find_future_session_terms(std::int32_t isin_id, std::int32_t sess_id, std::uint64_t expected_lifenum) const;
    [[nodiscard]] std::span<const MatchingMapSnapshot> matching_map() const;
    [[nodiscard]] std::span<const SystemMessageSnapshot> system_messages() const;
    [[nodiscard]] std::span<const LimitSnapshot> limits() const;
    [[nodiscard]] LimitLookup find_limit_by_code(const std::string& code) const;
    [[nodiscard]] std::size_t limit_row_count() const noexcept;
    [[nodiscard]] std::size_t unknown_limit_row_count() const noexcept;
    [[nodiscard]] std::span<const PositionSnapshot> positions() const;
    [[nodiscard]] std::span<const OwnOrderSnapshot> own_orders() const;
    [[nodiscard]] std::span<const OwnTradeSnapshot> own_trades() const;

    // Typed REFDATA provenance queries for the rows used to qualify a futures
    // target.  The optional is empty when the requested row is not currently
    // committed in the current REFDATA LifeNum epoch.
    [[nodiscard]] std::optional<SourceRowProvenance> instrument_source_provenance(generated::TableCode table_code,
                                                                                  std::int32_t isin_id) const;
    [[nodiscard]] std::optional<SourceRowProvenance> session_source_provenance(generated::TableCode table_code,
                                                                               std::int32_t sess_id) const;
    [[nodiscard]] std::optional<std::uint64_t> refdata_lifenum() const;

    // A regular-table-scoped USERORDERBOOK refresh makes the periodic snapshot
    // inconsistent while preserving listener ONLINE/currentness.
    void invalidate_periodic_snapshot(generated::StreamCode stream_code, generated::TableCode table_code);

    void on_event(const fake::ScenarioSpec& scenario, const fake::EventSpec& event,
                  const fake::EngineState& state) override;
    void on_stream_row(const fake::ScenarioSpec& scenario, const fake::EventSpec& event, const fake::RowSpec& row,
                       std::span<const fake::FieldValueSpec> fields, const fake::EngineState& state) override;
    void on_transaction_commit(const fake::ScenarioSpec& scenario, const fake::EventSpec& commit_event,
                               const fake::EngineState& state) override;

  private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace moex::plaza2::private_state
