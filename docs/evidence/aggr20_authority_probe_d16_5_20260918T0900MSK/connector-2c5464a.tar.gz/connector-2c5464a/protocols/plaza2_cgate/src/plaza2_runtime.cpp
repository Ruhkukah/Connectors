#include "moex/plaza2/cgate/plaza2_runtime.hpp"

#include "plaza2_generated_metadata.hpp"
#include "moex/plaza2/cgate/plaza2_public_decode.hpp"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstddef>
#include <cstdint>
#include <ctime>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#include <dlfcn.h>

namespace moex::plaza2::cgate {
namespace detail {
std::string sha256_file(const std::filesystem::path&);
}

namespace {

using CgResult = std::uint32_t;
using CgListenerCallback = CgResult (*)(void* conn, void* listener, void* msg, void* data);

constexpr std::uint32_t kCgErrOk = 0;
constexpr std::uint32_t kCgRangeBegin = 131072;
constexpr std::uint32_t kCgErrInternal = kCgRangeBegin;
constexpr std::uint32_t kCgErrInvalidArgument = kCgRangeBegin + 1;
constexpr std::uint32_t kCgErrUnsupported = kCgRangeBegin + 2;
constexpr std::uint32_t kCgErrTimeout = kCgRangeBegin + 3;
constexpr std::uint32_t kCgErrMore = kCgRangeBegin + 4;
constexpr std::uint32_t kCgErrIncorrectState = kCgRangeBegin + 5;
constexpr std::uint32_t kCgErrBufferTooSmall = kCgRangeBegin + 7;
// CGate p2err 36866 / 0x9002: a declared service is temporarily not
// exposed by the remote route. It is not a static listener-name failure.
constexpr std::uint32_t kCgErrServiceUnavailable = 36866;

constexpr std::uint32_t kCgKeyName = 2;
constexpr std::uint32_t kCgPubNeedReply = 1;

constexpr std::uint32_t kCgMsgOpen = 0x100;
constexpr std::uint32_t kCgMsgClose = 0x101;
constexpr std::uint32_t kCgMsgData = 0x110;
constexpr std::uint32_t kCgMsgStreamData = 0x120;
constexpr std::uint32_t kCgMsgTnBegin = 0x200;
constexpr std::uint32_t kCgMsgTnCommit = 0x210;
constexpr std::uint32_t kCgMsgP2MqTimeout = 0x1001;
constexpr std::uint32_t kCgMsgP2replLifenum = 0x1110;
constexpr std::uint32_t kCgMsgP2replClearDeleted = 0x1111;
constexpr std::uint32_t kCgMsgP2replOnline = 0x1112;
constexpr std::uint32_t kCgMsgP2replReplState = 0x1115;

constexpr std::string_view kSchemeFilename = "forts_scheme.ini";
constexpr std::array<std::string_view, 6> kProdConfigFiles = {
    "links_public.prod.ini", "links_public.rezerv.ini", "prod.ini",
    "auth_client.ini",       "client_router.ini",       "router.ini",
};
constexpr std::array<std::string_view, 10> kTestConfigFiles = {
    "links_public.t0.ini",
    "links_public.t1.ini",
    "links_public.game.ini",
    "links_public.custom.ini",
    "t0.ini",
    "t1.ini",
    "game.ini",
    "auth_client.ini",
    "client_router.ini",
    "router.ini",
};
constexpr std::array<std::string_view, 15> kRequiredSymbols = {
    "cg_env_open",   "cg_env_close",    "cg_conn_new",      "cg_conn_destroy",  "cg_conn_open",
    "cg_conn_close", "cg_conn_process", "cg_conn_getstate", "cg_lsn_new",       "cg_lsn_destroy",
    "cg_lsn_open",   "cg_lsn_close",    "cg_lsn_getstate",  "cg_lsn_getscheme", "cg_getstr",
};
constexpr std::array<std::string_view, 14> kRequiredTradingSymbols = {
    "cg_conn_process", "cg_lsn_new",    "cg_lsn_destroy", "cg_lsn_open",    "cg_lsn_close",
    "cg_lsn_getstate", "cg_pub_new",    "cg_pub_open",    "cg_pub_close",   "cg_pub_destroy",
    "cg_pub_getstate", "cg_pub_msgnew", "cg_pub_post",    "cg_pub_msgfree",
};

struct ReviewedRuntimeIdentity {
    std::string_view spectra_release;
    std::string_view scheme_sha256;
    std::string_view library_sha256;
    std::string_view runtime_version;
};

// Exact, reviewed TEST runtime identities. SPECTRA93 remains supported as
// historical provenance; SPECTRA9.9.0 is the current T1 qualification target.
constexpr std::array<ReviewedRuntimeIdentity, 2> kReviewedRuntimeIdentities = {{
    {
        "SPECTRA93",
        "cc3ab53b792eb1354b17615612abf173158e2f9dd78604bc47a121badf54b1c2",
        "c1a1752026806a6c7364326ab29794d0b85c1f9db26ec3fdbb509190e5b0a4a2",
        "6.93.1.5675",
    },
    {
        "SPECTRA9.9.0",
        "7b93117ee435fd0cb2849b677fc32a9d581364b6ee9afeac9c6c002875400746",
        "f63e726a8482b793c3af755a8dc2b9ebb5cd727d88fb58ebb3fe9704a155ce6f",
        "6.102.0.6118",
    },
}};

constexpr std::array<std::string_view, 4> kLibraryFilenameCandidates = {
#if defined(__APPLE__)
    "libcgate.dylib",
    "libcgate.so",
#else
    "libcgate.so",
    "libcgate64.so",
#endif
    "cgate.dll",
    "cgate64.dll",
};

struct RuntimeApi {
    void* library_handle{nullptr};

    CgResult (*env_open)(const char* settings){nullptr};
    CgResult (*env_close)(){nullptr};
    CgResult (*conn_new)(const char* settings, void** connptr){nullptr};
    CgResult (*conn_destroy)(void* conn){nullptr};
    CgResult (*conn_open)(void* conn, const char* settings){nullptr};
    CgResult (*conn_close)(void* conn){nullptr};
    CgResult (*conn_process)(void* conn, std::uint32_t timeout, void* reserved){nullptr};
    CgResult (*conn_getstate)(void* conn, std::uint32_t* state){nullptr};
    CgResult (*lsn_new)(void* conn, const char* settings, CgListenerCallback callback, void* data,
                        void** lsnptr){nullptr};
    CgResult (*lsn_destroy)(void* listener){nullptr};
    CgResult (*lsn_open)(void* listener, const char* settings){nullptr};
    CgResult (*lsn_close)(void* listener){nullptr};
    CgResult (*lsn_getstate)(void* listener, std::uint32_t* state){nullptr};
    CgResult (*lsn_getscheme)(void* listener, void** schemeptr){nullptr};
    CgResult (*pub_new)(void* conn, const char* settings, void** pubptr){nullptr};
    CgResult (*pub_open)(void* publisher, const char* settings){nullptr};
    CgResult (*pub_close)(void* publisher){nullptr};
    CgResult (*pub_destroy)(void* publisher){nullptr};
    CgResult (*pub_getstate)(void* publisher, std::uint32_t* state){nullptr};
    CgResult (*pub_msgnew)(void* publisher, std::uint32_t id_type, const void* id, void** msgptr){nullptr};
    CgResult (*pub_post)(void* publisher, void* msg, std::uint32_t flags){nullptr};
    CgResult (*pub_msgfree)(void* publisher, void* msg){nullptr};
    CgResult (*getstr)(const char* type, const void* data, char* buffer, std::size_t* buffer_size){nullptr};
};

struct RuntimeLibraryCloser {
    void operator()(RuntimeApi* api) const noexcept {
        if (api == nullptr) {
            return;
        }
        if (api->library_handle != nullptr) {
            ::dlclose(api->library_handle);
        }
        delete api;
    }
};

struct RuntimeSchemeField {
    std::string field_name;
    std::string type_token;
};

struct CgValuePair {
    CgValuePair* next;
    char* key;
    char* value;
};

struct CgFieldValueDesc {
    CgFieldValueDesc* next;
    char* name;
    char* desc;
    void* value;
    void* mask;
};

struct CgMessageDesc;

struct CgFieldDesc {
    CgFieldDesc* next;
    std::uint32_t id;
    char* name;
    char* desc;
    char* type;
    std::size_t size;
    std::size_t offset;
    void* def_value;
    std::size_t num_values;
    CgFieldValueDesc* values;
    CgValuePair* hints;
    std::size_t max_count;
    CgFieldDesc* count_field;
    CgMessageDesc* type_msg;
};

struct CgIndexFieldDesc {
    CgIndexFieldDesc* next;
    CgFieldDesc* field;
    std::uint32_t sort_order;
};

struct CgIndexDesc {
    CgIndexDesc* next;
    std::size_t num_fields;
    CgIndexFieldDesc* fields;
    char* name;
    char* desc;
    CgValuePair* hints;
};

struct CgMessageDesc {
    CgMessageDesc* next;
    std::size_t size;
    std::size_t num_fields;
    CgFieldDesc* fields;
    std::uint32_t id;
    char* name;
    char* desc;
    CgValuePair* hints;
    std::size_t num_indices;
    CgIndexDesc* indices;
    std::size_t align;
};

struct CgSchemeDesc {
    std::uint32_t scheme_type;
    std::uint32_t features;
    std::size_t num_messages;
    CgMessageDesc* messages;
    CgValuePair* hints;
};

struct CgMsg {
    std::uint32_t type;
    std::size_t data_size;
    void* data;
    std::int64_t owner_id;
};

struct CgMsgStreamData {
    std::uint32_t type;
    std::size_t data_size;
    void* data;
    std::int64_t owner_id;
    std::size_t msg_index;
    std::uint32_t msg_id;
    const char* msg_name;
    std::int64_t rev;
    std::size_t num_nulls;
    std::uint8_t* nulls;
    std::uint64_t user_id;
};

// Reviewed MOEX CGate 9.3 and 9.9 cgate.h layout: cg_msg_data_t includes
// owner_id and msg_index/msg_id/msg_name/user_id/addr/ref_msg; it has no
// revision or presence-map fields.
struct CgMsgData {
    std::uint32_t type;
    std::size_t data_size;
    void* data;
    std::int64_t owner_id;
    std::size_t msg_index;
    std::uint32_t msg_id;
    const char* msg_name;
    std::uint32_t user_id;
    const char* addr;
    CgMsgData* ref_msg;
};

struct CgTime {
    std::uint16_t year;
    std::uint8_t month;
    std::uint8_t day;
    std::uint8_t hour;
    std::uint8_t minute;
    std::uint8_t second;
    std::uint16_t msec;
};

struct ClearDeletedPayload {
    std::uint32_t table_idx;
    std::int64_t table_rev;
    std::uint32_t flags;
};

struct CgDataLifeNum {
    std::uint32_t life_number;
    std::uint32_t flags;
};

struct RuntimeSchemeTable {
    std::string scheme_name;
    std::string table_name;
    std::vector<RuntimeSchemeField> fields;
};

struct ParsedRuntimeScheme {
    Plaza2VersionMarkers markers;
    std::vector<RuntimeSchemeTable> tables;
};

struct ReviewedSignatureEntry {
    std::string example_name;
    std::size_t count{0};
};

struct RuntimeSignatureEntry {
    std::string example_name;
    std::size_t count{0};
};

struct RuntimeTableEntry {
    std::string example_name;
    std::vector<RuntimeSchemeField> fields;
};

struct ReviewedTableEntry {
    std::string example_name;
    std::vector<generated::FieldDescriptor> fields;
};

struct SchemeTableKey {
    std::string stream_name;
    std::string table_name;

    [[nodiscard]] std::string display_name() const {
        return stream_name + "." + table_name;
    }

    friend bool operator<(const SchemeTableKey& lhs, const SchemeTableKey& rhs) noexcept {
        if (lhs.stream_name != rhs.stream_name) {
            return lhs.stream_name < rhs.stream_name;
        }
        return lhs.table_name < rhs.table_name;
    }
};

[[nodiscard]] std::string trim_copy(std::string_view value) {
    std::size_t begin = 0;
    while (begin < value.size() && std::isspace(static_cast<unsigned char>(value[begin])) != 0) {
        ++begin;
    }
    std::size_t end = value.size();
    while (end > begin && std::isspace(static_cast<unsigned char>(value[end - 1])) != 0) {
        --end;
    }
    return std::string(value.substr(begin, end - begin));
}

[[nodiscard]] std::string sanitize_token(std::string_view value) {
    std::string result;
    result.reserve(value.size());
    for (const char ch : value) {
        if (std::isalnum(static_cast<unsigned char>(ch)) != 0) {
            result.push_back(static_cast<char>(std::tolower(static_cast<unsigned char>(ch))));
            continue;
        }
        result.push_back('_');
    }
    while (!result.empty() && result.back() == '_') {
        result.pop_back();
    }
    return result;
}

[[nodiscard]] std::string read_file_to_string(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    std::ostringstream buffer;
    buffer << input.rdbuf();
    return buffer.str();
}

[[nodiscard]] std::vector<std::string> read_file_lines(const std::filesystem::path& path) {
    std::ifstream input(path);
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(input, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        lines.push_back(std::move(line));
    }
    return lines;
}

[[nodiscard]] std::filesystem::path resolve_optional_path(const std::filesystem::path& root,
                                                          const std::filesystem::path& value) {
    if (value.empty()) {
        return {};
    }
    if (value.is_absolute()) {
        return value;
    }
    return root / value;
}

[[nodiscard]] std::optional<std::filesystem::path>
first_existing_directory(const std::vector<std::filesystem::path>& candidates) {
    for (const auto& candidate : candidates) {
        if (std::filesystem::is_directory(candidate)) {
            return candidate;
        }
    }
    return std::nullopt;
}

[[nodiscard]] std::optional<std::filesystem::path> resolve_library_path(const Plaza2Settings& settings) {
    const auto explicit_path = resolve_optional_path(settings.runtime_root, settings.library_path);
    if (!explicit_path.empty()) {
        return explicit_path;
    }

    const std::array<std::filesystem::path, 3> candidate_dirs = {
        settings.runtime_root / "bin",
        settings.runtime_root / "lib",
        settings.runtime_root,
    };
    for (const auto& dir : candidate_dirs) {
        for (const auto file_name : kLibraryFilenameCandidates) {
            const auto candidate = dir / file_name;
            if (std::filesystem::exists(candidate)) {
                return candidate;
            }
        }
    }
    return std::nullopt;
}

[[nodiscard]] std::optional<std::filesystem::path> resolve_scheme_dir(const Plaza2Settings& settings) {
    const auto explicit_dir = resolve_optional_path(settings.runtime_root, settings.scheme_dir);
    if (!explicit_dir.empty()) {
        return explicit_dir;
    }
    return first_existing_directory({
        settings.runtime_root / "scheme",
        settings.runtime_root / "Scheme",
        settings.runtime_root / "ini",
        settings.runtime_root,
    });
}

[[nodiscard]] std::optional<std::filesystem::path> resolve_config_dir(const Plaza2Settings& settings) {
    const auto explicit_dir = resolve_optional_path(settings.runtime_root, settings.config_dir);
    if (!explicit_dir.empty()) {
        return explicit_dir;
    }
    return first_existing_directory({
        settings.runtime_root / "config",
        settings.runtime_root / "cfg",
        settings.runtime_root / "ini",
        settings.runtime_root,
    });
}

[[nodiscard]] std::vector<std::string> collect_present_config_files(const std::filesystem::path& config_dir) {
    std::vector<std::string> present;
    if (!std::filesystem::is_directory(config_dir)) {
        return present;
    }
    for (const auto& entry : std::filesystem::directory_iterator(config_dir)) {
        if (!entry.is_regular_file()) {
            continue;
        }
        if (entry.path().extension() != ".ini") {
            continue;
        }
        present.push_back(entry.path().filename().string());
    }
    std::sort(present.begin(), present.end());
    return present;
}

[[nodiscard]] std::optional<std::filesystem::path> env_open_ini_path(std::string_view settings) {
    constexpr std::string_view kPrefix = "ini=";
    const auto begin = settings.find(kPrefix);
    if (begin == std::string_view::npos) {
        return std::nullopt;
    }
    const auto value_begin = begin + kPrefix.size();
    const auto value_end = settings.find(';', value_begin);
    const auto value = trim_copy(settings.substr(value_begin, value_end - value_begin));
    if (value.empty()) {
        return std::nullopt;
    }
    return std::filesystem::path(value);
}

[[nodiscard]] std::filesystem::path resolve_config_ini_path(const std::filesystem::path& config_dir,
                                                            const std::filesystem::path& ini_path) {
    if (ini_path.is_absolute()) {
        return ini_path;
    }
    const auto direct = config_dir / ini_path;
    if (std::filesystem::exists(direct)) {
        return direct;
    }
    if (ini_path.has_parent_path() && ini_path.begin() != ini_path.end() && *ini_path.begin() == "config") {
        return config_dir / ini_path.filename();
    }
    return direct;
}

[[nodiscard]] std::vector<std::string> expected_config_files_for_settings(const Plaza2Settings& settings) {
    const auto ini_path = env_open_ini_path(settings.env_open_settings);
    if (ini_path.has_value()) {
        return {ini_path->filename().string()};
    }
    auto expected = Plaza2RuntimeProbe::expected_config_filenames(settings.environment);
    return {expected.begin(), expected.end()};
}

[[nodiscard]] std::string canonical_table_signature(std::span<const RuntimeSchemeField> fields) {
    std::ostringstream out;
    for (const auto& field : fields) {
        out << field.field_name << ':' << field.type_token << ';';
    }
    return out.str();
}

[[nodiscard]] std::string canonical_table_signature(std::span<const generated::FieldDescriptor> fields) {
    std::ostringstream out;
    for (const auto& field : fields) {
        out << field.field_name << ':' << field.type_token << ';';
    }
    return out.str();
}

[[nodiscard]] bool table_is_in_list(std::string_view stream_name, std::string_view table_name,
                                    std::span<const std::pair<std::string_view, std::string_view>> tables) {
    return std::any_of(tables.begin(), tables.end(),
                       [&](const auto& table) { return table.first == stream_name && table.second == table_name; });
}

[[nodiscard]] bool is_required_private_state_table(std::string_view stream_name, std::string_view table_name) {
    static constexpr std::array<std::pair<std::string_view, std::string_view>, 22> kRequiredTables = {{
        {"FORTS_REFDATA_REPL", "session"},
        {"FORTS_REFDATA_REPL", "fut_instruments"},
        {"FORTS_REFDATA_REPL", "sys_messages"},
        {"FORTS_REFDATA_REPL", "opt_sess_contents"},
        {"FORTS_REFDATA_REPL", "multileg_dict"},
        {"FORTS_REFDATA_REPL", "instr2matching_map"},
        {"FORTS_TRADE_REPL", "orders_log"},
        {"FORTS_TRADE_REPL", "multileg_orders_log"},
        {"FORTS_TRADE_REPL", "user_deal"},
        {"FORTS_TRADE_REPL", "user_multileg_deal"},
        {"FORTS_TRADE_REPL", "heartbeat"},
        {"FORTS_TRADE_REPL", "sys_events"},
        {"FORTS_USERORDERBOOK_REPL", "orders"},
        {"FORTS_USERORDERBOOK_REPL", "multileg_orders"},
        {"FORTS_USERORDERBOOK_REPL", "orders_currentday"},
        {"FORTS_USERORDERBOOK_REPL", "multileg_orders_currentday"},
        {"FORTS_USERORDERBOOK_REPL", "info"},
        {"FORTS_USERORDERBOOK_REPL", "info_currentday"},
        {"FORTS_POS_REPL", "position"},
        {"FORTS_POS_REPL", "info"},
        {"FORTS_PART_REPL", "part"},
        {"FORTS_PART_REPL", "sys_events"},
    }};
    return table_is_in_list(stream_name, table_name, kRequiredTables);
}

[[nodiscard]] bool is_warning_only_private_state_table(std::string_view stream_name, std::string_view table_name) {
    static constexpr std::array<std::pair<std::string_view, std::string_view>, 1> kWarningOnlyTables = {{
        {"FORTS_REFDATA_REPL", "clearing_members"},
    }};
    return table_is_in_list(stream_name, table_name, kWarningOnlyTables);
}

[[nodiscard]] bool is_fatal_scheme_table_drift(const SchemeTableKey& key) {
    if (is_warning_only_private_state_table(key.stream_name, key.table_name)) {
        return false;
    }
    return is_required_private_state_table(key.stream_name, key.table_name);
}

[[nodiscard]] std::string normalized_runtime_stream_name(std::string_view scheme_name) {
    static constexpr std::array<std::pair<std::string_view, std::string_view>, 5> kRuntimeSchemeAliases = {{
        {"REFDATA", "FORTS_REFDATA_REPL"},
        {"Trade", "FORTS_TRADE_REPL"},
        {"OrderBook", "FORTS_USERORDERBOOK_REPL"},
        {"POS", "FORTS_POS_REPL"},
        {"PART", "FORTS_PART_REPL"},
    }};
    for (const auto& [runtime_name, reviewed_name] : kRuntimeSchemeAliases) {
        if (scheme_name == runtime_name) {
            return std::string(reviewed_name);
        }
    }
    return std::string(scheme_name);
}

[[nodiscard]] std::optional<std::size_t> integer_type_size(std::string_view type_token) {
    if (type_token == "i1" || type_token == "u1") {
        return 1;
    }
    if (type_token == "i2" || type_token == "u2") {
        return 2;
    }
    if (type_token == "i4" || type_token == "u4") {
        return 4;
    }
    if (type_token == "i8" || type_token == "u8") {
        return 8;
    }
    return std::nullopt;
}

[[nodiscard]] bool compatible_runtime_field_type(std::string_view reviewed_type, std::string_view runtime_type) {
    if (reviewed_type == runtime_type) {
        return true;
    }
    const auto reviewed_integer_size = integer_type_size(reviewed_type);
    const auto runtime_integer_size = integer_type_size(runtime_type);
    return reviewed_integer_size.has_value() && runtime_integer_size.has_value() &&
           *reviewed_integer_size == *runtime_integer_size;
}

[[nodiscard]] bool is_reviewed_absent_field(std::string_view spectra_release, const SchemeTableKey& table,
                                            std::string_view field_name) {
    if (spectra_release != "SPECTRA9.9.0") {
        return false;
    }
    static constexpr std::array<std::tuple<std::string_view, std::string_view, std::string_view>, 6>
        kSpectra99RemovedFields = {{
            {"FORTS_PART_REPL", "part", "vm_intercl"},
            {"FORTS_PART_REPL", "part", "premium_intercl"},
            {"FORTS_REFDATA_REPL", "fut_instruments", "step_price_interclr"},
            {"FORTS_REFDATA_REPL", "session", "inter_cl_begin"},
            {"FORTS_REFDATA_REPL", "session", "inter_cl_end"},
            {"FORTS_REFDATA_REPL", "session", "inter_cl_state"},
        }};
    return std::ranges::any_of(kSpectra99RemovedFields, [&](const auto& field) {
        return std::get<0>(field) == table.stream_name && std::get<1>(field) == table.table_name &&
               std::get<2>(field) == field_name;
    });
}

[[nodiscard]] bool parse_runtime_scheme(const std::filesystem::path& scheme_path, ParsedRuntimeScheme& out_scheme,
                                        std::string& error_message) {
    out_scheme = {};
    RuntimeSchemeTable* current_table = nullptr;
    std::string current_section;

    for (const auto& raw_line : read_file_lines(scheme_path)) {
        const auto line = trim_copy(raw_line);
        if (line.empty()) {
            continue;
        }
        if (line.rfind(';', 0) == 0) {
            const auto comment = trim_copy(std::string_view(line).substr(1));
            constexpr std::string_view kSpectraPrefix = "Spectra release:";
            constexpr std::string_view kDdsPrefix = "DDS version:";
            constexpr std::string_view kTargetPrefixA = "Target poligon:";
            constexpr std::string_view kTargetPrefixB = "Target polygon:";
            if (comment.rfind(kSpectraPrefix, 0) == 0) {
                out_scheme.markers.spectra_release = trim_copy(std::string_view(comment).substr(kSpectraPrefix.size()));
            } else if (comment.rfind(kDdsPrefix, 0) == 0) {
                out_scheme.markers.dds_version = trim_copy(std::string_view(comment).substr(kDdsPrefix.size()));
            } else if (comment.rfind(kTargetPrefixA, 0) == 0) {
                out_scheme.markers.target_polygon = trim_copy(std::string_view(comment).substr(kTargetPrefixA.size()));
            } else if (comment.rfind(kTargetPrefixB, 0) == 0) {
                out_scheme.markers.target_polygon = trim_copy(std::string_view(comment).substr(kTargetPrefixB.size()));
            }
            continue;
        }

        if (line.front() == '[' && line.back() == ']') {
            current_section = line.substr(1, line.size() - 2);
            current_table = nullptr;
            if (current_section.rfind("table:", 0) == 0) {
                const auto rest = current_section.substr(6);
                const auto separator = rest.find(':');
                if (separator == std::string::npos) {
                    error_message = "invalid table section: " + current_section;
                    return false;
                }
                out_scheme.tables.push_back({
                    .scheme_name = rest.substr(0, separator),
                    .table_name = rest.substr(separator + 1),
                    .fields = {},
                });
                current_table = &out_scheme.tables.back();
            }
            continue;
        }

        if (current_table == nullptr) {
            continue;
        }

        if (line.rfind("field=", 0) != 0) {
            continue;
        }
        const auto remainder = line.substr(6);
        const auto comma = remainder.find(',');
        if (comma == std::string::npos) {
            error_message = "invalid field line: " + line;
            return false;
        }
        const auto field_name = trim_copy(std::string_view(remainder).substr(0, comma));
        const auto type_token = trim_copy(std::string_view(remainder).substr(comma + 1));
        if (field_name.empty() || type_token.empty()) {
            error_message = "invalid empty field token in line: " + line;
            return false;
        }
        current_table->fields.push_back({field_name, type_token});
    }

    for (const auto& table : out_scheme.tables) {
        if (table.table_name.empty() || table.fields.empty()) {
            error_message = "runtime scheme contains empty table definition";
            return false;
        }
    }
    if (out_scheme.tables.empty()) {
        error_message = "runtime scheme contains no table sections";
        return false;
    }
    return true;
}

[[nodiscard]] Plaza2Compatibility combine_compatibility(Plaza2Compatibility lhs, Plaza2Compatibility rhs) noexcept {
    if (lhs == Plaza2Compatibility::Incompatible || rhs == Plaza2Compatibility::Incompatible) {
        return Plaza2Compatibility::Incompatible;
    }
    if (lhs == Plaza2Compatibility::Unknown || rhs == Plaza2Compatibility::Unknown) {
        return Plaza2Compatibility::Unknown;
    }
    if (lhs == Plaza2Compatibility::CompatibleWithWarnings || rhs == Plaza2Compatibility::CompatibleWithWarnings) {
        return Plaza2Compatibility::CompatibleWithWarnings;
    }
    if (lhs == Plaza2Compatibility::Compatible && rhs == Plaza2Compatibility::Compatible) {
        return Plaza2Compatibility::Compatible;
    }
    return Plaza2Compatibility::Unknown;
}

void push_issue(std::vector<Plaza2ProbeIssue>& issues, Plaza2ProbeIssueCode code, bool fatal, std::string subject,
                std::string message) {
    issues.push_back({
        .code = code,
        .fatal = fatal,
        .subject = std::move(subject),
        .message = std::move(message),
    });
}

[[nodiscard]] Plaza2Compatibility compatibility_from_issues(const std::vector<Plaza2ProbeIssue>& issues) {
    bool has_warning = false;
    for (const auto& issue : issues) {
        if (issue.fatal) {
            return Plaza2Compatibility::Incompatible;
        }
        has_warning = true;
    }
    return has_warning ? Plaza2Compatibility::CompatibleWithWarnings : Plaza2Compatibility::Compatible;
}

[[nodiscard]] std::unique_ptr<RuntimeApi, RuntimeLibraryCloser>
load_runtime_api(const std::filesystem::path& library_path, std::vector<std::string>* resolved_symbols,
                 std::vector<Plaza2ProbeIssue>* issues) {
    int dlopen_flags = RTLD_NOW | RTLD_LOCAL;
#if defined(__has_feature)
#if __has_feature(address_sanitizer)
    // Apple ASan keeps global-variable shadow state for instrumented dylibs
    // across dlclose/dlopen cycles. Keep sanitizer-loaded runtimes resident so
    // repeated TEST fixture hosts do not turn valid metadata reads into stale
    // global-buffer reports; production builds retain normal unloading.
    dlopen_flags |= RTLD_NODELETE;
#endif
#endif
    const auto* handle = ::dlopen(library_path.c_str(), dlopen_flags);
    if (handle == nullptr) {
        if (issues != nullptr) {
            push_issue(*issues, Plaza2ProbeIssueCode::MissingLibrary, true, library_path.string(),
                       std::string("failed to load CGate runtime library: ") + ::dlerror());
        }
        return {};
    }

    auto api = std::unique_ptr<RuntimeApi, RuntimeLibraryCloser>(new RuntimeApi{});
    api->library_handle = const_cast<void*>(handle);
    auto load_symbol = [&](const char* name, auto& target) -> bool {
        void* symbol = ::dlsym(api->library_handle, name);
        if (symbol == nullptr) {
            if (issues != nullptr) {
                push_issue(*issues, Plaza2ProbeIssueCode::MissingSymbol, true, name,
                           std::string("required CGate symbol is missing from runtime library: ") + name);
            }
            return false;
        }
        if (resolved_symbols != nullptr) {
            resolved_symbols->push_back(name);
        }
        target = reinterpret_cast<std::remove_reference_t<decltype(target)>>(symbol);
        return true;
    };
    auto load_optional_symbol = [&](const char* name, auto& target) {
        void* symbol = ::dlsym(api->library_handle, name);
        if (symbol == nullptr) {
            return;
        }
        if (resolved_symbols != nullptr) {
            resolved_symbols->push_back(name);
        }
        target = reinterpret_cast<std::remove_reference_t<decltype(target)>>(symbol);
    };

    bool ok = true;
    ok = load_symbol("cg_env_open", api->env_open) && ok;
    ok = load_symbol("cg_env_close", api->env_close) && ok;
    ok = load_symbol("cg_conn_new", api->conn_new) && ok;
    ok = load_symbol("cg_conn_destroy", api->conn_destroy) && ok;
    ok = load_symbol("cg_conn_open", api->conn_open) && ok;
    ok = load_symbol("cg_conn_close", api->conn_close) && ok;
    ok = load_symbol("cg_conn_process", api->conn_process) && ok;
    ok = load_symbol("cg_conn_getstate", api->conn_getstate) && ok;
    ok = load_symbol("cg_lsn_new", api->lsn_new) && ok;
    ok = load_symbol("cg_lsn_destroy", api->lsn_destroy) && ok;
    ok = load_symbol("cg_lsn_open", api->lsn_open) && ok;
    ok = load_symbol("cg_lsn_close", api->lsn_close) && ok;
    ok = load_symbol("cg_lsn_getstate", api->lsn_getstate) && ok;
    ok = load_symbol("cg_lsn_getscheme", api->lsn_getscheme) && ok;
    ok = load_symbol("cg_getstr", api->getstr) && ok;
    load_optional_symbol("cg_pub_new", api->pub_new);
    load_optional_symbol("cg_pub_open", api->pub_open);
    load_optional_symbol("cg_pub_close", api->pub_close);
    load_optional_symbol("cg_pub_destroy", api->pub_destroy);
    load_optional_symbol("cg_pub_getstate", api->pub_getstate);
    load_optional_symbol("cg_pub_msgnew", api->pub_msgnew);
    load_optional_symbol("cg_pub_post", api->pub_post);
    load_optional_symbol("cg_pub_msgfree", api->pub_msgfree);
    if (!ok) {
        return {};
    }
    return api;
}

[[nodiscard]] CgResult noop_listener_callback(void*, void*, void*, void*) {
    return kCgErrOk;
}

[[nodiscard]] Plaza2SchemeDriftReport compare_runtime_scheme(const std::filesystem::path& scheme_path,
                                                             const Plaza2Settings& settings) {
    Plaza2SchemeDriftReport report;
    report.reviewed_table_count = generated::TableDescriptors().size();
    report.reviewed_field_count = generated::FieldDescriptors().size();
    report.runtime_scheme_sha256 = detail::sha256_file(scheme_path);

    ParsedRuntimeScheme parsed;
    std::string parse_error;
    if (!parse_runtime_scheme(scheme_path, parsed, parse_error)) {
        push_issue(report.issues, Plaza2ProbeIssueCode::RuntimeSchemeParseFailed, true, scheme_path.filename().string(),
                   "failed to parse runtime forts_scheme.ini: " + parse_error);
        report.compatibility = Plaza2Compatibility::Incompatible;
        return report;
    }

    report.runtime_table_count = parsed.tables.size();
    std::size_t runtime_field_count = 0;
    std::map<SchemeTableKey, RuntimeTableEntry> runtime_by_name;
    for (const auto& table : parsed.tables) {
        runtime_field_count += table.fields.size();
        const SchemeTableKey key{.stream_name = normalized_runtime_stream_name(table.scheme_name),
                                 .table_name = table.table_name};
        auto& entry = runtime_by_name[key];
        if (entry.example_name.empty()) {
            entry.example_name = key.display_name();
        }
        entry.fields = table.fields;
    }
    report.runtime_field_count = runtime_field_count;

    std::map<SchemeTableKey, ReviewedTableEntry> reviewed_by_name;
    for (const auto& table : generated::TableDescriptors()) {
        const auto fields = generated::FieldsForTable(table.table_code);
        const SchemeTableKey key{.stream_name = std::string(table.stream_name),
                                 .table_name = std::string(table.table_name)};
        auto& entry = reviewed_by_name[key];
        if (entry.example_name.empty()) {
            entry.example_name = key.display_name();
        }
        entry.fields.assign(fields.begin(), fields.end());
    }

    if (!settings.expected_scheme_sha256.empty() && report.runtime_scheme_sha256 != settings.expected_scheme_sha256) {
        push_issue(report.issues, Plaza2ProbeIssueCode::FileHashMismatch, true, scheme_path.filename().string(),
                   "runtime scheme hash mismatch: expected " + settings.expected_scheme_sha256 + ", got " +
                       report.runtime_scheme_sha256);
    }
    if (!settings.expected_spectra_release.empty() &&
        parsed.markers.spectra_release != settings.expected_spectra_release) {
        push_issue(report.issues, Plaza2ProbeIssueCode::UnsupportedVersion, true, scheme_path.filename().string(),
                   "runtime spectra release mismatch: expected " + settings.expected_spectra_release + ", got " +
                       parsed.markers.spectra_release);
    }

    auto record_drift = [&](const SchemeTableKey& key, Plaza2ProbeIssueCode code, bool fatal, std::string subject,
                            std::string message) {
        push_issue(report.issues, code, fatal, std::move(subject), message);
        auto& count = fatal ? report.fatal_drift_count : report.warning_drift_count;
        auto& tables = fatal ? report.fatal_drift_tables : report.warning_drift_tables;
        auto& last_reason = fatal ? report.last_fatal_drift_reason : report.last_warning_drift_reason;
        ++count;
        const auto display_name = key.display_name();
        if (std::find(tables.begin(), tables.end(), display_name) == tables.end()) {
            tables.push_back(display_name);
        }
        last_reason = std::move(message);
    };

    std::set<SchemeTableKey> table_names;
    for (const auto& [table_name, _] : reviewed_by_name) {
        table_names.insert(table_name);
    }
    for (const auto& [table_name, _] : runtime_by_name) {
        table_names.insert(table_name);
    }

    for (const auto& table_name : table_names) {
        const auto reviewed_it = reviewed_by_name.find(table_name);
        const auto runtime_it = runtime_by_name.find(table_name);
        if (reviewed_it == reviewed_by_name.end()) {
            record_drift(table_name, Plaza2ProbeIssueCode::RuntimeTableUnexpected,
                         is_fatal_scheme_table_drift(table_name), table_name.display_name(),
                         "runtime scheme exposes unexpected table not present in Phase 3B baseline: " +
                             table_name.display_name());
            continue;
        }
        if (runtime_it == runtime_by_name.end()) {
            record_drift(table_name, Plaza2ProbeIssueCode::ReviewedTableMissing,
                         is_fatal_scheme_table_drift(table_name), reviewed_it->second.example_name,
                         "runtime scheme is missing reviewed table '" + table_name.display_name() + "'");
            continue;
        }

        const auto runtime_signature = canonical_table_signature(runtime_it->second.fields);
        const auto reviewed_signature = canonical_table_signature(reviewed_it->second.fields);
        if (runtime_signature == reviewed_signature) {
            continue;
        }

        if (is_required_private_state_table(table_name.stream_name, table_name.table_name)) {
            std::map<std::string_view, std::string_view> runtime_fields;
            for (const auto& field : runtime_it->second.fields) {
                runtime_fields.emplace(field.field_name, field.type_token);
            }
            bool material_required_drift = false;
            for (const auto& field : reviewed_it->second.fields) {
                const auto runtime_field_it = runtime_fields.find(field.field_name);
                if (runtime_field_it == runtime_fields.end() &&
                    is_reviewed_absent_field(parsed.markers.spectra_release, table_name, field.field_name)) {
                    continue;
                }
                if (runtime_field_it == runtime_fields.end() ||
                    !compatible_runtime_field_type(field.type_token, runtime_field_it->second)) {
                    material_required_drift = true;
                    break;
                }
            }
            if (material_required_drift) {
                record_drift(table_name, Plaza2ProbeIssueCode::ReviewedTableSignatureMismatch, true,
                             reviewed_it->second.example_name,
                             "runtime scheme diverged materially from reviewed projected table signature for '" +
                                 table_name.display_name() + "'");
                continue;
            }
        }

        record_drift(table_name, Plaza2ProbeIssueCode::ReviewedTableSignatureMismatch, false,
                     reviewed_it->second.example_name,
                     "runtime scheme differs from reviewed non-material table signature for '" +
                         table_name.display_name() + "'");
    }

    report.compatibility = compatibility_from_issues(report.issues);
    return report;
}

} // namespace

struct Plaza2RuntimeSharedState {
    Plaza2Settings settings;
    std::unique_ptr<RuntimeApi, RuntimeLibraryCloser> api;
};

struct RuntimeFieldPlan {
    std::string name;
    generated::FieldCode field_code{kNoFieldCode};
    generated::ValueClass value_class{generated::ValueClass::kSignedInteger};
    std::string type_token;
    std::size_t offset{0};
    std::size_t size{0};
    std::size_t ordinal{0};
};

struct RuntimeMessagePlan {
    generated::TableCode table_code{kNoTableCode};
    std::size_t msg_index{0};
    std::string msg_name;
    std::vector<RuntimeFieldPlan> fields;
};

template <typename T> [[nodiscard]] T read_unaligned(const void* data) {
    T value{};
    std::memcpy(&value, data, sizeof(T));
    return value;
}

[[nodiscard]] ClearDeletedPayload read_clear_deleted_payload(const void* data) {
    const auto* bytes = static_cast<const std::byte*>(data);
    return {
        .table_idx = read_unaligned<std::uint32_t>(bytes),
        .table_rev = read_unaligned<std::int64_t>(bytes + sizeof(std::uint32_t)),
        .flags = read_unaligned<std::uint32_t>(bytes + sizeof(std::uint32_t) + sizeof(std::int64_t)),
    };
}

[[nodiscard]] std::int64_t read_signed_integer(const void* data, std::size_t size) {
    switch (size) {
    case 1:
        return read_unaligned<std::int8_t>(data);
    case 2:
        return read_unaligned<std::int16_t>(data);
    case 4:
        return read_unaligned<std::int32_t>(data);
    case 8:
        return read_unaligned<std::int64_t>(data);
    default:
        return 0;
    }
}

[[nodiscard]] std::uint64_t read_unsigned_integer(const void* data, std::size_t size) {
    switch (size) {
    case 1:
        return read_unaligned<std::uint8_t>(data);
    case 2:
        return read_unaligned<std::uint16_t>(data);
    case 4:
        return read_unaligned<std::uint32_t>(data);
    case 8:
        return read_unaligned<std::uint64_t>(data);
    default:
        return 0;
    }
}

[[nodiscard]] std::string copy_c_string(const char* data, std::size_t size) {
    if (data == nullptr || size == 0) {
        return {};
    }
    const auto* end = static_cast<const char*>(std::memchr(data, '\0', size));
    const auto count = end == nullptr ? size : static_cast<std::size_t>(end - data);
    return std::string(data, count);
}

[[nodiscard]] std::uint64_t to_unix_seconds(const CgTime& value) {
    std::tm timestamp{};
    timestamp.tm_year = static_cast<int>(value.year) - 1900;
    timestamp.tm_mon = static_cast<int>(value.month) - 1;
    timestamp.tm_mday = static_cast<int>(value.day);
    timestamp.tm_hour = static_cast<int>(value.hour);
    timestamp.tm_min = static_cast<int>(value.minute);
    timestamp.tm_sec = static_cast<int>(value.second);
    return static_cast<std::uint64_t>(::timegm(&timestamp));
}

[[nodiscard]] Plaza2Error convert_runtime_field_to_string(RuntimeApi& api, std::string_view type_token,
                                                          const void* data, std::string& out) {
    if (api.getstr == nullptr) {
        return {
            .code = Plaza2ErrorCode::DecodeFailed,
            .runtime_code = 0,
            .message = "cg_getstr is not available in the loaded CGate runtime",
        };
    }

    std::size_t buffer_size = 64;
    out.assign(buffer_size, '\0');
    auto result = api.getstr(std::string(type_token).c_str(), data, out.data(), &buffer_size);
    if (result == kCgErrBufferTooSmall) {
        out.assign(buffer_size, '\0');
        result = api.getstr(std::string(type_token).c_str(), data, out.data(), &buffer_size);
    }
    if (result != kCgErrOk) {
        auto error = translate_plaza2_result("cg_getstr", result);
        if (!error) {
            error.code = Plaza2ErrorCode::DecodeFailed;
            error.message = "cg_getstr failed while decoding runtime field";
            error.runtime_code = result;
        }
        return error;
    }

    if (buffer_size < out.size()) {
        out.resize(buffer_size);
    }
    while (!out.empty() && out.back() == '\0') {
        out.pop_back();
    }
    return {};
}

[[nodiscard]] const generated::TableDescriptor* find_table_descriptor_for_stream(generated::StreamCode stream_code,
                                                                                 std::string_view table_name) {
    for (const auto& table : generated::TablesForStream(stream_code)) {
        if (table.table_name == table_name) {
            return &table;
        }
    }
    return nullptr;
}

[[nodiscard]] const RuntimeMessagePlan* find_runtime_message_plan(std::span<const RuntimeMessagePlan> plans,
                                                                  std::size_t msg_index, std::string_view msg_name) {
    for (const auto& plan : plans) {
        if (plan.msg_index == msg_index) {
            return &plan;
        }
    }
    for (const auto& plan : plans) {
        if (plan.msg_name == msg_name) {
            return &plan;
        }
    }
    return nullptr;
}

[[nodiscard]] const RuntimeMessagePlan*
find_clear_deleted_runtime_message_plan(std::span<const RuntimeMessagePlan> plans, std::size_t table_idx) {
    if (const auto* plan = find_runtime_message_plan(plans, table_idx, {}); plan != nullptr) {
        return plan;
    }
    if (table_idx < plans.size()) {
        return &plans[table_idx];
    }
    return nullptr;
}

struct Plaza2ListenerCallbackState {
    std::shared_ptr<Plaza2RuntimeSharedState> shared;
    generated::StreamCode stream_code{kNoStreamCode};
    Plaza2ListenerEventHandler* handler{nullptr};
    void* listener_handle{nullptr};
    bool scheme_loaded{false};
    std::vector<RuntimeMessagePlan> message_plans;
    std::vector<Plaza2DecodedFieldValue> decoded_fields;
    std::vector<std::string> text_storage;
    Plaza2Error last_error;
};

[[nodiscard]] Plaza2Error ensure_listener_scheme_loaded(Plaza2ListenerCallbackState& state) {
    if (state.scheme_loaded) {
        return {};
    }
    if (state.stream_code == kNoStreamCode) {
        state.scheme_loaded = true;
        return {};
    }
    if (!state.shared || !state.shared->api || state.shared->api->lsn_getscheme == nullptr ||
        state.listener_handle == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "listener scheme load requires an active CGate listener handle",
        };
    }

    void* raw_scheme = nullptr;
    const auto scheme_result = state.shared->api->lsn_getscheme(state.listener_handle, &raw_scheme);
    const auto scheme_error = translate_plaza2_result("cg_lsn_getscheme", scheme_result);
    if (scheme_error) {
        return scheme_error;
    }

    const auto* scheme = static_cast<CgSchemeDesc*>(raw_scheme);
    if (scheme == nullptr || scheme->messages == nullptr) {
        return {
            .code = Plaza2ErrorCode::DecodeFailed,
            .runtime_code = 0,
            .message = "CGate listener scheme is empty after CG_MSG_OPEN",
        };
    }

    const bool raw = state.handler && state.handler->wants_raw_replication();
    const auto mismatch = []() -> Plaza2Error {
        return {.code = Plaza2ErrorCode::DecodeFailed,
                .message = "public replication scheme differs from qualified 9.9 wire layout"};
    };
    std::size_t expected_count = 0;
    if (raw) {
        for (const auto& table : public_wire::kTables) {
            expected_count += table.stream == state.stream_code;
        }
        if (!expected_count || scheme->num_messages != expected_count)
            return mismatch();
    }
    state.message_plans.clear();
    std::size_t msg_index = 0;
    for (auto* message = scheme->messages; message != nullptr; message = message->next, ++msg_index) {
        const auto message_name = message->name == nullptr ? std::string{} : std::string(message->name);
        const auto* table = find_table_descriptor_for_stream(state.stream_code, message_name);
        if (table == nullptr) {
            if (raw)
                return mismatch();
            continue;
        }
        if (raw) {
            const auto* wire = public_wire::table(table->table_code);
            if (!wire || wire->index != msg_index || wire->size != message->size ||
                wire->fields.size() != message->num_fields)
                return mismatch();
            auto* field = message->fields;
            for (const auto& expected : wire->fields) {
                if (!field || !field->name || !field->type || expected.name != field->name ||
                    expected.type != field->type || expected.offset != field->offset || expected.size != field->size)
                    return mismatch();
                field = field->next;
            }
            if (field)
                return mismatch();
        }

        RuntimeMessagePlan plan;
        plan.table_code = table->table_code;
        plan.msg_index = msg_index;
        plan.msg_name = message_name;

        auto* field = message->fields;
        std::size_t ordinal = 0;
        while (field != nullptr) {
            const auto field_name = field->name == nullptr ? std::string_view{} : std::string_view(field->name);
            const auto fields = generated::FieldsForTable(table->table_code);
            const generated::FieldDescriptor* descriptor = nullptr;
            for (const auto& candidate : fields) {
                if (candidate.field_name == field_name) {
                    descriptor = &candidate;
                    break;
                }
            }
            if (descriptor == nullptr) {
                ++ordinal;
                field = field->next;
                continue;
            }

            plan.fields.push_back({
                .name = std::string(field_name),
                .field_code = descriptor->field_code,
                .value_class = descriptor->value_class,
                .type_token = field->type == nullptr ? std::string(descriptor->type_token) : std::string(field->type),
                .offset = field->offset,
                .size = field->size,
                .ordinal = ordinal,
            });
            field = field->next;
            ++ordinal;
        }

        state.message_plans.push_back(std::move(plan));
    }

    if (raw && state.message_plans.size() != expected_count)
        return mismatch();
    if (state.message_plans.empty()) {
        return {
            .code = Plaza2ErrorCode::DecodeFailed,
            .runtime_code = 0,
            .message = "listener scheme does not expose any reviewed tables for the configured stream",
        };
    }

    state.scheme_loaded = true;
    return {};
}

[[nodiscard]] Plaza2Error dispatch_listener_event(Plaza2ListenerCallbackState& state,
                                                  const Plaza2ListenerEvent& event) {
    if (state.handler == nullptr) {
        return {};
    }
    const auto error = state.handler->on_plaza2_listener_event(event);
    if (auto* observer = state.shared->settings.qualification_observer)
        observer->observe(event, error);
    return error;
}

[[nodiscard]] CgResult listener_callback_bridge(void*, void*, void* raw_msg, void* data) {
    auto* state = static_cast<Plaza2ListenerCallbackState*>(data);
    if (state == nullptr || raw_msg == nullptr) {
        return kCgErrOk;
    }

    auto fail = [&](Plaza2Error error) -> CgResult {
        state->last_error = std::move(error);
        if (auto* observer = state->shared->settings.qualification_observer)
            observer->runtime_state(14, static_cast<std::uint32_t>(state->stream_code), state->last_error.runtime_code,
                                    static_cast<std::uint32_t>(state->last_error.code));
        if (state->handler)
            state->handler->on_plaza2_listener_error(state->last_error);
        return state->last_error.runtime_code == 0 ? kCgErrInternal : state->last_error.runtime_code;
    };

    try {
        const auto* msg = static_cast<CgMsg*>(raw_msg);
        switch (msg->type) {
        case kCgMsgOpen: {
            state->scheme_loaded = false;
            if (const auto error = ensure_listener_scheme_loaded(*state); error) {
                return fail(error);
            }
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::Open,
                .stream_code = state->stream_code,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgClose: {
            const auto close_reason = msg->data != nullptr && msg->data_size >= sizeof(std::uint32_t)
                                          ? read_unaligned<std::uint32_t>(msg->data)
                                          : 0U;
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::Close,
                .stream_code = state->stream_code,
                .close_reason = close_reason,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgTnBegin: {
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::TransactionBegin,
                .stream_code = state->stream_code,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgTnCommit: {
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::TransactionCommit,
                .stream_code = state->stream_code,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgP2replOnline: {
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::Online,
                .stream_code = state->stream_code,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgP2replLifenum: {
            std::uint64_t life_number = 0;
            if (msg->data != nullptr && msg->data_size >= sizeof(CgDataLifeNum)) {
                life_number = static_cast<std::uint64_t>(static_cast<const CgDataLifeNum*>(msg->data)->life_number);
            } else if (msg->data != nullptr && msg->data_size >= sizeof(std::uint32_t)) {
                life_number = read_unaligned<std::uint32_t>(msg->data);
            }
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::LifeNum,
                .stream_code = state->stream_code,
                .unsigned_value = life_number,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgP2replClearDeleted: {
            constexpr auto kPackedClearDeletedSize =
                sizeof(std::uint32_t) + sizeof(std::int64_t) + sizeof(std::uint32_t);
            if (msg->data == nullptr || msg->data_size < kPackedClearDeletedSize) {
                return fail({
                    .code = Plaza2ErrorCode::DecodeFailed,
                    .runtime_code = 0,
                    .message = "CG_MSG_P2REPL_CLEARDELETED did not provide cg_data_cleardeleted_t payload",
                });
            }
            const auto payload = read_clear_deleted_payload(msg->data);
            const auto* plan = find_clear_deleted_runtime_message_plan(state->message_plans, payload.table_idx);
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::ClearDeleted,
                .stream_code = state->stream_code,
                .table_code = plan == nullptr ? kNoTableCode : plan->table_code,
                .signed_value = payload.table_rev,
                .clear_deleted_flags = payload.flags,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgP2replReplState: {
            const auto text =
                msg->data == nullptr ? std::string_view{} : std::string_view(static_cast<const char*>(msg->data));
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::ReplState,
                .stream_code = state->stream_code,
                .text_value = text,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgData: {
            if (state->stream_code != kNoStreamCode) {
                return fail({
                    .code = Plaza2ErrorCode::DecodeFailed,
                    .runtime_code = 0,
                    .message = "CG_MSG_DATA is only valid on an untyped CGate reply listener",
                });
            }
            const auto* payload = static_cast<const CgMsgData*>(raw_msg);
            const auto raw_payload =
                payload->data == nullptr
                    ? std::span<const std::byte>{}
                    : std::span<const std::byte>{static_cast<const std::byte*>(payload->data), payload->data_size};
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::StreamData,
                .stream_code = kNoStreamCode,
                .message_id = static_cast<std::int32_t>(payload->msg_id),
                .message_name = payload->msg_name == nullptr ? std::string_view{} : std::string_view(payload->msg_name),
                .user_id = payload->user_id,
                .raw_payload = raw_payload,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgP2MqTimeout: {
            if (state->stream_code != kNoStreamCode) {
                return fail({
                    .code = Plaza2ErrorCode::DecodeFailed,
                    .runtime_code = 0,
                    .message = "CG_MSG_P2MQ_TIMEOUT is only valid on an untyped CGate reply listener",
                });
            }
            // Reviewed MOEX CGate 9.3/9.9 cgate.h: timeout uses cg_msg_data_t;
            // only the originating uint32 user_id is contractually meaningful.
            const auto* payload = static_cast<const CgMsgData*>(raw_msg);
            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::Timeout,
                .stream_code = kNoStreamCode,
                .user_id = payload->user_id,
            };
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        case kCgMsgStreamData: {
            const auto* payload = static_cast<const CgMsgStreamData*>(raw_msg);
            const auto* plan = find_runtime_message_plan(
                state->message_plans, payload->msg_index,
                payload->msg_name == nullptr ? std::string_view{} : std::string_view(payload->msg_name));
            if (plan == nullptr) {
                return fail({
                    .code = Plaza2ErrorCode::DecodeFailed,
                    .runtime_code = 0,
                    .message =
                        "CG_MSG_STREAM_DATA referenced a runtime message that is not covered by the reviewed baseline",
                });
            }

            if (state->handler && state->handler->wants_raw_replication()) {
                // No per-record strings, heap allocation, timestamp rounding or decimal formatting.
                if (plan->msg_index != payload->msg_index || !payload->data ||
                    (payload->num_nulls && !payload->nulls)) {
                    return fail({.code = Plaza2ErrorCode::DecodeFailed,
                                 .message = "invalid public raw record index or buffer"});
                }
                const auto event = Plaza2ListenerEvent{
                    .kind = Plaza2ListenerEventKind::StreamData,
                    .stream_code = state->stream_code,
                    .table_code = plan->table_code,
                    .raw_payload = {static_cast<const std::byte*>(payload->data), payload->data_size},
                    .signed_value = payload->rev,
                    .raw_nulls = {payload->nulls, payload->num_nulls},
                    .table_index = payload->msg_index,
                };
                if (const auto error = dispatch_listener_event(*state, event); error)
                    return fail(error);
                return kCgErrOk;
            }

            state->decoded_fields.clear();
            state->text_storage.clear();
            state->decoded_fields.reserve(plan->fields.size());
            state->text_storage.reserve(plan->fields.size());

            for (const auto& field : plan->fields) {
                if (payload->data == nullptr || payload->data_size < field.offset + field.size) {
                    return fail({
                        .code = Plaza2ErrorCode::DecodeFailed,
                        .runtime_code = 0,
                        .message = "CG_MSG_STREAM_DATA payload size is smaller than the runtime field plan",
                    });
                }
                if (payload->nulls != nullptr && field.ordinal < payload->num_nulls &&
                    payload->nulls[field.ordinal] != 0U) {
                    continue;
                }

                const auto* field_ptr = static_cast<const std::byte*>(payload->data) + field.offset;
                Plaza2DecodedFieldValue decoded{
                    .field_code = field.field_code,
                    .raw_value = {field_ptr, field.size},
                    .type_token = field.type_token,
                };

                switch (field.value_class) {
                case generated::ValueClass::kSignedInteger:
                    decoded.kind = Plaza2DecodedValueKind::SignedInteger;
                    decoded.signed_value = read_signed_integer(field_ptr, field.size);
                    break;
                case generated::ValueClass::kUnsignedInteger:
                    decoded.kind = Plaza2DecodedValueKind::UnsignedInteger;
                    decoded.unsigned_value = read_unsigned_integer(field_ptr, field.size);
                    break;
                case generated::ValueClass::kFixedString:
                    decoded.kind = Plaza2DecodedValueKind::String;
                    state->text_storage.push_back(
                        field.type_token == "a" ? copy_c_string(reinterpret_cast<const char*>(field_ptr), 1)
                                                : copy_c_string(reinterpret_cast<const char*>(field_ptr), field.size));
                    decoded.text_value = state->text_storage.back();
                    break;
                case generated::ValueClass::kDecimal:
                    decoded.kind = Plaza2DecodedValueKind::Decimal;
                    if (field.type_token == "d16.5" && field.size == sizeof(public_wire::Bcd16_5)) {
                        const auto exact = public_wire::decimal_value(
                            public_wire::load<public_wire::Bcd16_5>({field_ptr, field.size}));
                        if (exact.has_value()) {
                            decoded.decimal_mantissa = exact->mantissa;
                            decoded.decimal_scale = exact->scale;
                            decoded.decimal_exact = true;
                        }
                    }
                    state->text_storage.emplace_back();
                    if (const auto error = convert_runtime_field_to_string(*state->shared->api, field.type_token,
                                                                           field_ptr, state->text_storage.back());
                        error) {
                        return fail(error);
                    }
                    decoded.text_value = state->text_storage.back();
                    break;
                case generated::ValueClass::kFloatingPoint:
                    decoded.kind = Plaza2DecodedValueKind::FloatingPoint;
                    state->text_storage.emplace_back();
                    if (const auto error = convert_runtime_field_to_string(*state->shared->api, field.type_token,
                                                                           field_ptr, state->text_storage.back());
                        error) {
                        return fail(error);
                    }
                    decoded.text_value = state->text_storage.back();
                    break;
                case generated::ValueClass::kTimestamp:
                    decoded.kind = Plaza2DecodedValueKind::Timestamp;
                    decoded.unsigned_value = to_unix_seconds(read_unaligned<CgTime>(field_ptr));
                    break;
                case generated::ValueClass::kBinary:
                    continue;
                }

                state->decoded_fields.push_back(decoded);
            }

            const auto event = Plaza2ListenerEvent{
                .kind = Plaza2ListenerEventKind::StreamData,
                .stream_code = state->stream_code,
                .table_code = plan->table_code,
                .fields = state->decoded_fields,
                .raw_payload = {static_cast<const std::byte*>(payload->data), payload->data_size},
                .signed_value = payload->rev,
                .raw_nulls = {payload->nulls, payload->num_nulls},
                .table_index = payload->msg_index,
            };
            if (auto* observer = state->shared->settings.qualification_observer;
                observer && observer->wants_forensic_row(event)) {
                if (payload->data_size > 65536 || payload->num_nulls > 4096 || plan->fields.size() > 128)
                    return fail(
                        {.code = Plaza2ErrorCode::DecodeFailed, .message = "target forensic row exceeds bounds"});
                Plaza2ForensicRow raw;
                raw.stream_code = state->stream_code;
                raw.table_code = plan->table_code;
                raw.table_index = plan->msg_index;
                raw.message_size = payload->data_size;
                raw.message_name = plan->msg_name;
                const auto* bytes = static_cast<const std::byte*>(payload->data);
                raw.payload.assign(bytes, bytes + payload->data_size);
                if (payload->nulls)
                    raw.nulls.assign(payload->nulls, payload->nulls + payload->num_nulls);
                for (const auto& field : plan->fields) {
                    const auto& name = field.name;
                    if (name != "replID" && name != "replRev" && name != "replAct" && name != "isin_id" &&
                        name != "sess_id" && name != "isin" && name != "short_isin" && name != "limit_up" &&
                        name != "limit_down" && name != "settlement_price_open" && name != "settlement_price" &&
                        name != "buy_deposit" && name != "sell_deposit" && name != "roundto" && name != "min_step" &&
                        name != "step_price")
                        continue;
                    Plaza2ForensicField item{.name = name,
                                             .type = field.type_token,
                                             .offset = field.offset,
                                             .size = field.size,
                                             .ordinal = field.ordinal,
                                             .is_null = payload->nulls && field.ordinal < payload->num_nulls &&
                                                        payload->nulls[field.ordinal] != 0};
                    if (!item.is_null) {
                        // Independent name/negotiated-offset route: no generated FieldCode lookup.
                        std::array<char, 256> buffer{};
                        std::size_t size = buffer.size();
                        item.conversion_result = state->shared->api->getstr(field.type_token.c_str(),
                                                                            bytes + field.offset, buffer.data(), &size);
                        if (item.conversion_result == kCgErrOk && size <= buffer.size())
                            item.independent_value = copy_c_string(buffer.data(), size);
                        else if (item.conversion_result == kCgErrOk)
                            item.conversion_result = kCgErrBufferTooSmall;
                        for (const auto& value : state->decoded_fields) {
                            if (value.field_code != field.field_code)
                                continue;
                            item.generic_value = value.kind == Plaza2DecodedValueKind::SignedInteger
                                                     ? std::to_string(value.signed_value)
                                                 : value.kind == Plaza2DecodedValueKind::UnsignedInteger
                                                     ? std::to_string(value.unsigned_value)
                                                     : std::string(value.text_value);
                            break;
                        }
                    }
                    item.equal = item.is_null ||
                                 (item.conversion_result == kCgErrOk && item.generic_value == item.independent_value);
                    raw.fields.push_back(std::move(item));
                }
                observer->forensic_row(std::move(raw));
            }
            if (const auto error = dispatch_listener_event(*state, event); error) {
                return fail(error);
            }
            return kCgErrOk;
        }
        default:
            if (state->handler && state->handler->wants_raw_replication()) {
                return fail(
                    {.code = Plaza2ErrorCode::DecodeFailed, .message = "unsupported public replication callback"});
            }
            return kCgErrOk;
        }
    } catch (const std::exception& error) {
        return fail({
            .code = Plaza2ErrorCode::CallbackFailed,
            .runtime_code = 0,
            .message = std::string("PLAZA II listener callback failed: ") + error.what(),
        });
    } catch (...) {
        return fail({
            .code = Plaza2ErrorCode::CallbackFailed,
            .runtime_code = 0,
            .message = "PLAZA II listener callback failed with an unknown exception",
        });
    }
}

Plaza2Error validate_plaza2_settings(const Plaza2Settings& settings) {
    if (settings.runtime_root.empty()) {
        return {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .runtime_code = 0,
            .message = "runtime_root must be set for PLAZA II runtime probing",
        };
    }
    return {};
}

std::string_view plaza2_compatibility_name(Plaza2Compatibility compatibility) noexcept {
    switch (compatibility) {
    case Plaza2Compatibility::Unknown:
        return "Unknown";
    case Plaza2Compatibility::Compatible:
        return "Compatible";
    case Plaza2Compatibility::CompatibleWithWarnings:
        return "CompatibleWithWarnings";
    case Plaza2Compatibility::Incompatible:
        return "Incompatible";
    }
    return "Unknown";
}

std::string make_plaza2_application_name(std::string_view prefix, std::string_view scope, std::uint32_t instance) {
    std::string sanitized_prefix = sanitize_token(prefix);
    std::string sanitized_scope = sanitize_token(scope);
    if (sanitized_prefix.empty()) {
        sanitized_prefix = "connectors";
    }
    if (sanitized_scope.empty()) {
        sanitized_scope = "plaza2";
    }
    std::ostringstream name;
    name << sanitized_prefix << '_' << sanitized_scope << '_' << instance;
    auto result = name.str();
    if (result.size() > 64) {
        result.resize(64);
    }
    return result;
}

Plaza2Error translate_plaza2_result(std::string_view operation, std::uint32_t runtime_code) {
    if (runtime_code == kCgErrOk || (operation == "cg_conn_process" && runtime_code == kCgErrTimeout)) {
        return {};
    }

    Plaza2Error error;
    error.runtime_code = runtime_code;
    error.code = Plaza2ErrorCode::UnknownRuntimeResult;

    switch (runtime_code) {
    case kCgErrInvalidArgument:
        error.code = Plaza2ErrorCode::InvalidConfiguration;
        error.message = std::string(operation) + ": CG_ERR_INVALIDARGUMENT";
        break;
    case kCgErrIncorrectState:
        error.code = Plaza2ErrorCode::AdapterState;
        error.message = std::string(operation) + ": CG_ERR_INCORRECTSTATE";
        break;
    case kCgErrInternal:
        error.code = Plaza2ErrorCode::RuntimeCallFailed;
        error.message = std::string(operation) + ": CG_ERR_INTERNAL";
        break;
    case kCgErrUnsupported:
        error.code = Plaza2ErrorCode::RuntimeCallFailed;
        error.message = std::string(operation) + ": CG_ERR_UNSUPPORTED";
        break;
    case kCgErrMore:
        error.code = Plaza2ErrorCode::RuntimeCallFailed;
        error.message = std::string(operation) + ": CG_ERR_MORE";
        break;
    case kCgErrTimeout:
        error.code = Plaza2ErrorCode::RuntimeCallFailed;
        error.message = std::string(operation) + ": CG_ERR_TIMEOUT";
        break;
    case kCgErrServiceUnavailable:
        error.code = Plaza2ErrorCode::AdapterState;
        error.message = std::string(operation) + ": p2err 36866=0x9002 SERV:NO_SERVICE";
        break;
    default:
        error.message = std::string(operation) + ": CGate returned runtime code " + std::to_string(runtime_code);
        break;
    }
    return error;
}

Plaza2RuntimeProbeReport Plaza2RuntimeProbe::probe(const Plaza2Settings& settings) {
    Plaza2RuntimeProbeReport report;
    report.layout.runtime_root = settings.runtime_root;
    report.layout.expected_config_files = expected_config_files_for_settings(settings);

    const auto validation_error = validate_plaza2_settings(settings);
    if (validation_error) {
        push_issue(report.issues, Plaza2ProbeIssueCode::UnsupportedLayout, true, "settings", validation_error.message);
        report.compatibility = Plaza2Compatibility::Incompatible;
        return report;
    }

    report.runtime_root_present = std::filesystem::exists(settings.runtime_root);
    if (!report.runtime_root_present) {
        push_issue(report.issues, Plaza2ProbeIssueCode::MissingRuntimeRoot, true, settings.runtime_root.string(),
                   "runtime root does not exist");
        report.compatibility = Plaza2Compatibility::Incompatible;
        return report;
    }

    const auto library_path = resolve_library_path(settings);
    if (!library_path.has_value()) {
        push_issue(report.issues, Plaza2ProbeIssueCode::MissingLibrary, true, settings.runtime_root.string(),
                   "CGate runtime library was not found under runtime_root/bin, runtime_root/lib, or runtime_root");
    } else {
        report.layout.library_path = *library_path;
        report.runtime_library_present = std::filesystem::exists(*library_path);
        if (report.runtime_library_present) {
            report.runtime_library_sha256 = detail::sha256_file(*library_path);
            if (!settings.expected_runtime_library_sha256.empty() &&
                report.runtime_library_sha256 != settings.expected_runtime_library_sha256) {
                push_issue(report.issues, Plaza2ProbeIssueCode::FileHashMismatch, true,
                           library_path->filename().string(),
                           "runtime library hash mismatch: expected " + settings.expected_runtime_library_sha256 +
                               ", got " + report.runtime_library_sha256);
            }
        }
        auto library_issues = std::vector<Plaza2ProbeIssue>{};
        auto resolved_symbols = std::vector<std::string>{};
        auto api = load_runtime_api(*library_path, &resolved_symbols, &library_issues);
        report.runtime_library_loadable = api != nullptr;
        report.fake_runtime_marker_present =
            api != nullptr && ::dlsym(api->library_handle, "moex_fake_cgate_runtime_v1") != nullptr;
        report.resolved_symbols = std::move(resolved_symbols);
        for (const auto required_symbol : kRequiredTradingSymbols) {
            if (std::ranges::find(report.resolved_symbols, required_symbol) == report.resolved_symbols.end()) {
                report.missing_trading_symbols.emplace_back(required_symbol);
            }
        }
        report.trading_capable = report.runtime_library_loadable && report.missing_trading_symbols.empty();
        report.issues.insert(report.issues.end(), library_issues.begin(), library_issues.end());
    }

    const auto scheme_dir = resolve_scheme_dir(settings);
    if (!scheme_dir.has_value()) {
        push_issue(report.issues, Plaza2ProbeIssueCode::MissingSchemeDirectory, true, settings.runtime_root.string(),
                   "scheme directory was not found under runtime_root/scheme, runtime_root/Scheme, runtime_root/ini, "
                   "or runtime_root");
    } else {
        report.layout.scheme_dir = *scheme_dir;
        report.layout.scheme_path = *scheme_dir / kSchemeFilename;
        report.scheme_file_present = std::filesystem::exists(report.layout.scheme_path);
        if (!report.scheme_file_present) {
            push_issue(report.issues, Plaza2ProbeIssueCode::MissingSchemeFile, true, report.layout.scheme_path.string(),
                       "expected runtime scheme file is missing");
        } else {
            auto parsed_scheme = ParsedRuntimeScheme{};
            std::string parse_error;
            if (parse_runtime_scheme(report.layout.scheme_path, parsed_scheme, parse_error)) {
                report.layout.version_markers = parsed_scheme.markers;
            }
            report.scheme_drift = compare_runtime_scheme(report.layout.scheme_path, settings);
            report.issues.insert(report.issues.end(), report.scheme_drift.issues.begin(),
                                 report.scheme_drift.issues.end());
        }
    }

    if (report.fake_runtime_marker_present) {
        report.runtime_identity_recognized = true;
        report.runtime_version = "fake-runtime-v1";
    } else if (report.runtime_library_loadable && report.scheme_file_present) {
        for (const auto& identity : kReviewedRuntimeIdentities) {
            if (report.layout.version_markers.spectra_release == identity.spectra_release &&
                report.scheme_drift.runtime_scheme_sha256 == identity.scheme_sha256 &&
                report.runtime_library_sha256 == identity.library_sha256) {
                report.runtime_identity_recognized = true;
                report.runtime_version = identity.runtime_version;
                break;
            }
        }
        if (!report.runtime_identity_recognized) {
            push_issue(report.issues, Plaza2ProbeIssueCode::UnsupportedVersion, true, "runtime identity",
                       "CGate library and SPECTRA scheme combination is not an exact reviewed runtime identity");
        }
    }

    const auto config_dir = resolve_config_dir(settings);
    if (!config_dir.has_value()) {
        push_issue(report.issues, Plaza2ProbeIssueCode::MissingConfigDirectory, true, settings.runtime_root.string(),
                   "config directory was not found under runtime_root/config, runtime_root/cfg, runtime_root/ini, or "
                   "runtime_root");
    } else {
        report.layout.config_dir = *config_dir;
        report.config_dir_present = true;
        report.layout.present_config_files = collect_present_config_files(*config_dir);
        const std::set<std::string> expected(report.layout.expected_config_files.begin(),
                                             report.layout.expected_config_files.end());
        const std::set<std::string> present(report.layout.present_config_files.begin(),
                                            report.layout.present_config_files.end());
        for (const auto& expected_name : expected) {
            const auto expected_path =
                env_open_ini_path(settings.env_open_settings).has_value()
                    ? resolve_config_ini_path(*config_dir, *env_open_ini_path(settings.env_open_settings))
                    : *config_dir / expected_name;
            if (!std::filesystem::exists(expected_path)) {
                push_issue(report.issues, Plaza2ProbeIssueCode::MissingConfigFile, true, expected_name,
                           "expected config file is missing from resolved config directory");
            }
        }
        for (const auto& present_name : present) {
            if (!expected.contains(present_name)) {
                push_issue(report.issues, Plaza2ProbeIssueCode::UnexpectedConfigFile, false, present_name,
                           "unexpected config file is present in resolved config directory");
            }
        }
    }

    report.compatibility = compatibility_from_issues(report.issues);
    report.compatibility = combine_compatibility(report.compatibility, report.scheme_drift.compatibility);
    return report;
}

std::span<const std::string_view> Plaza2RuntimeProbe::expected_config_filenames(Plaza2Environment environment) {
    if (environment == Plaza2Environment::Prod) {
        return kProdConfigFiles;
    }
    return kTestConfigFiles;
}

std::span<const std::string_view> Plaza2RuntimeProbe::required_runtime_symbols() {
    return kRequiredSymbols;
}

std::span<const std::string_view> Plaza2RuntimeProbe::required_trading_symbols() {
    return kRequiredTradingSymbols;
}

Plaza2Env::~Plaza2Env() {
    if (open_) {
        static_cast<void>(close());
    }
}

Plaza2Error Plaza2Env::open(const Plaza2Settings& settings) {
    if (open_) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "cg_env_open called while PLAZA II environment is already open",
        };
    }
    if (settings.env_open_settings.empty()) {
        return {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .runtime_code = 0,
            .message = "env_open_settings must be set explicitly for Phase 3C adapter open",
        };
    }

    const auto library_path = resolve_library_path(settings);
    if (!library_path.has_value()) {
        return {
            .code = Plaza2ErrorCode::MissingRuntime,
            .runtime_code = 0,
            .message = "CGate runtime library could not be resolved from Plaza2Settings",
        };
    }

    auto state = std::make_shared<Plaza2RuntimeSharedState>();
    state->settings = settings;
    std::vector<Plaza2ProbeIssue> ignored_issues;
    state->api = load_runtime_api(*library_path, nullptr, &ignored_issues);
    if (!state->api) {
        return {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .runtime_code = 0,
            .message = ignored_issues.empty() ? "failed to load CGate runtime library" : ignored_issues.front().message,
        };
    }

    const auto result = state->api->env_open(settings.env_open_settings.c_str());
    const auto translated = translate_plaza2_result("cg_env_open", result);
    if (translated) {
        return translated;
    }

    shared_ = std::move(state);
    open_ = true;
    return {};
}

Plaza2Error Plaza2Env::close() {
    if (!open_ || !shared_ || !shared_->api) {
        return {};
    }
    const auto result = shared_->api->env_close();
    const auto translated = translate_plaza2_result("cg_env_close", result);
    if (!translated) {
        open_ = false;
        shared_.reset();
    }
    return translated;
}

bool Plaza2Env::is_open() const noexcept {
    return open_;
}

Plaza2Connection::~Plaza2Connection() {
    if (handle_ != nullptr) {
        static_cast<void>(destroy());
    }
}

Plaza2Error Plaza2Connection::create(Plaza2Env& env, std::string_view settings) {
    if (!env.open_ || !env.shared_ || !env.shared_->api) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "connection create requires an open PLAZA II environment",
        };
    }
    if (handle_ != nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "connection is already created",
        };
    }
    if (settings.empty()) {
        return {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .runtime_code = 0,
            .message = "connection settings must be provided explicitly in Phase 3C",
        };
    }

    shared_ = env.shared_;
    void* raw_handle = nullptr;
    const auto result = shared_->api->conn_new(std::string(settings).c_str(), &raw_handle);
    const auto translated = translate_plaza2_result("cg_conn_new", result);
    if (translated) {
        shared_.reset();
        return translated;
    }
    handle_ = raw_handle;
    return {};
}

Plaza2Error Plaza2Connection::open(std::string_view settings) {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "connection open requires a created connection",
        };
    }
    const std::string copied_settings(settings);
    const auto result = shared_->api->conn_open(handle_, copied_settings.empty() ? nullptr : copied_settings.c_str());
    return translate_plaza2_result("cg_conn_open", result);
}

Plaza2Error Plaza2Connection::process(std::uint32_t timeout_ms, std::uint32_t* runtime_code) {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "connection process requires a created connection",
        };
    }
    const auto result = shared_->api->conn_process(handle_, timeout_ms, nullptr);
    if (runtime_code != nullptr) {
        *runtime_code = result;
    }
    // Poll timeout is a successful no-event iteration, not a failed runtime call.
    if (result == kCgErrOk || result == kCgErrTimeout)
        return {};
    return translate_plaza2_result("cg_conn_process", result);
}

Plaza2Error Plaza2Connection::close() {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {};
    }
    return translate_plaza2_result("cg_conn_close", shared_->api->conn_close(handle_));
}

Plaza2Error Plaza2Connection::destroy() {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {};
    }
    const auto result = shared_->api->conn_destroy(handle_);
    const auto translated = translate_plaza2_result("cg_conn_destroy", result);
    if (!translated) {
        handle_ = nullptr;
        shared_.reset();
    }
    return translated;
}

Plaza2Error Plaza2Connection::state(std::uint32_t& out_state) const {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "connection state requires a created connection",
        };
    }
    return translate_plaza2_result("cg_conn_getstate", shared_->api->conn_getstate(handle_, &out_state));
}

bool Plaza2Connection::is_created() const noexcept {
    return handle_ != nullptr;
}

const Plaza2Error& Plaza2Listener::last_callback_error() const noexcept {
    static const Plaza2Error none;
    return callback_state_ ? callback_state_->last_error : none;
}

Plaza2Listener::Plaza2Listener() = default;

Plaza2Listener::~Plaza2Listener() {
    if (handle_ != nullptr) {
        static_cast<void>(destroy());
    }
}

Plaza2Listener::Plaza2Listener(Plaza2Listener&&) noexcept = default;

Plaza2Listener& Plaza2Listener::operator=(Plaza2Listener&&) noexcept = default;

Plaza2Error Plaza2Listener::create(Plaza2Connection& connection, std::string_view settings) {
    return create(connection, kNoStreamCode, settings, nullptr);
}

Plaza2Error Plaza2Listener::create(Plaza2Connection& connection, generated::StreamCode stream_code,
                                   std::string_view settings, Plaza2ListenerEventHandler* handler) {
    if (!connection.shared_ || !connection.shared_->api || connection.handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "listener create requires a created connection",
        };
    }
    if (handle_ != nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "listener is already created",
        };
    }
    if (settings.empty()) {
        return {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .runtime_code = 0,
            .message = "listener settings must be provided explicitly in Phase 3C",
        };
    }

    shared_ = connection.shared_;
    callback_state_.reset();
    if (handler != nullptr) {
        callback_state_ = std::make_unique<Plaza2ListenerCallbackState>();
        callback_state_->shared = shared_;
        callback_state_->stream_code = stream_code;
        callback_state_->handler = handler;
    }

    void* raw_handle = nullptr;
    const std::string copied_settings(settings);
    const auto result =
        shared_->api->lsn_new(connection.handle_, copied_settings.c_str(),
                              handler == nullptr ? &noop_listener_callback : &listener_callback_bridge,
                              callback_state_ == nullptr ? nullptr : callback_state_.get(), &raw_handle);
    const auto translated = translate_plaza2_result("cg_lsn_new", result);
    if (translated) {
        callback_state_.reset();
        shared_.reset();
        return translated;
    }
    handle_ = raw_handle;
    if (callback_state_ != nullptr) {
        callback_state_->listener_handle = raw_handle;
    }
    return {};
}

Plaza2Error Plaza2Listener::open(std::string_view settings) {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "listener open requires a created listener",
        };
    }
    const std::string copied_settings(settings);
    return translate_plaza2_result(
        "cg_lsn_open", shared_->api->lsn_open(handle_, copied_settings.empty() ? nullptr : copied_settings.c_str()));
}

Plaza2Error Plaza2Listener::close() {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {};
    }
    return translate_plaza2_result("cg_lsn_close", shared_->api->lsn_close(handle_));
}

Plaza2Error Plaza2Listener::destroy() {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {};
    }
    const auto result = shared_->api->lsn_destroy(handle_);
    const auto translated = translate_plaza2_result("cg_lsn_destroy", result);
    if (!translated) {
        handle_ = nullptr;
        callback_state_.reset();
        shared_.reset();
    }
    return translated;
}

Plaza2Error Plaza2Listener::state(std::uint32_t& out_state) const {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "listener state requires a created listener",
        };
    }
    return translate_plaza2_result("cg_lsn_getstate", shared_->api->lsn_getstate(handle_, &out_state));
}

bool Plaza2Listener::is_created() const noexcept {
    return handle_ != nullptr;
}

Plaza2Publisher::~Plaza2Publisher() {
    if (handle_ != nullptr) {
        static_cast<void>(destroy());
    }
}

Plaza2Error Plaza2Publisher::create(Plaza2Connection& connection, std::string_view settings) {
    if (!connection.shared_ || !connection.shared_->api || connection.handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "publisher create requires a created PLAZA II connection",
        };
    }
    if (connection.shared_->api->pub_new == nullptr) {
        return {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .message = "loaded CGate runtime does not expose cg_pub_new",
        };
    }
    if (handle_ != nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "publisher is already created",
        };
    }
    if (settings.empty()) {
        return {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .message = "publisher settings must be provided explicitly",
        };
    }

    shared_ = connection.shared_;
    void* raw_handle = nullptr;
    const std::string copied_settings(settings);
    const auto result = shared_->api->pub_new(connection.handle_, copied_settings.c_str(), &raw_handle);
    const auto translated = translate_plaza2_result("cg_pub_new", result);
    if (translated) {
        shared_.reset();
        return translated;
    }
    handle_ = raw_handle;
    return {};
}

Plaza2Error Plaza2Publisher::open(std::string_view settings) {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "publisher open requires a created publisher",
        };
    }
    if (shared_->api->pub_open == nullptr) {
        return {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .message = "loaded CGate runtime does not expose cg_pub_open",
        };
    }
    const std::string copied_settings(settings);
    return translate_plaza2_result(
        "cg_pub_open", shared_->api->pub_open(handle_, copied_settings.empty() ? nullptr : copied_settings.c_str()));
}

Plaza2PublisherMessageResult Plaza2Publisher::post_by_message_name(std::string_view message_name,
                                                                   std::span<const std::byte> payload,
                                                                   std::uint32_t user_id, bool need_reply) {
    Plaza2PublisherMessageResult outcome;
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        outcome.validation_error = {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "publisher post requires a created publisher",
        };
        return outcome;
    }
    if (shared_->api->pub_msgnew == nullptr || shared_->api->pub_post == nullptr ||
        shared_->api->pub_msgfree == nullptr) {
        outcome.validation_error = {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .message = "loaded CGate runtime does not expose all publisher message symbols",
        };
        return outcome;
    }
    if (message_name.empty() || payload.empty()) {
        outcome.validation_error = {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .message = "publisher post requires explicit message name and payload",
        };
        return outcome;
    }

    void* raw_msg = nullptr;
    const std::string copied_name(message_name);
    ++call_counts_.msgnew;
    const auto allocation_result = shared_->api->pub_msgnew(handle_, kCgKeyName, copied_name.c_str(), &raw_msg);
    outcome.allocation_error = translate_plaza2_result("cg_pub_msgnew", allocation_result);
    if (outcome.allocation_error) {
        return outcome;
    }

    auto* msg = static_cast<CgMsgData*>(raw_msg);
    outcome.runtime_payload_size = msg == nullptr ? 0 : msg->data_size;
    if (msg == nullptr || msg->data == nullptr || msg->data_size != payload.size()) {
        outcome.validation_error = {
            .code = Plaza2ErrorCode::InvalidConfiguration,
            .message = "runtime publisher payload size does not match locked offline command payload",
        };
    } else {
        std::memcpy(msg->data, payload.data(), payload.size());
        msg->user_id = user_id;
        outcome.post_invoked = true;
        ++call_counts_.post;
        const auto post_result = shared_->api->pub_post(handle_, raw_msg, need_reply ? kCgPubNeedReply : 0U);
        outcome.post_error = translate_plaza2_result("cg_pub_post", post_result);
        outcome.certainty =
            post_result == kCgErrOk ? Plaza2SubmissionCertainty::Posted : Plaza2SubmissionCertainty::PossiblySent;
    }

    const auto free_result = shared_->api->pub_msgfree(handle_, raw_msg);
    outcome.free_error = translate_plaza2_result("cg_pub_msgfree", free_result);
    return outcome;
}

Plaza2Error Plaza2Publisher::close() {
    if (!shared_ || !shared_->api || handle_ == nullptr || shared_->api->pub_close == nullptr) {
        return {};
    }
    return translate_plaza2_result("cg_pub_close", shared_->api->pub_close(handle_));
}

Plaza2Error Plaza2Publisher::destroy() {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {};
    }
    if (shared_->api->pub_destroy == nullptr) {
        return {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .message = "loaded CGate runtime does not expose cg_pub_destroy",
        };
    }
    const auto result = shared_->api->pub_destroy(handle_);
    const auto translated = translate_plaza2_result("cg_pub_destroy", result);
    if (!translated) {
        handle_ = nullptr;
        shared_.reset();
    }
    return translated;
}

Plaza2Error Plaza2Publisher::state(std::uint32_t& out_state) const {
    if (!shared_ || !shared_->api || handle_ == nullptr) {
        return {
            .code = Plaza2ErrorCode::AdapterState,
            .runtime_code = kCgErrIncorrectState,
            .message = "publisher state requires a created publisher",
        };
    }
    if (shared_->api->pub_getstate == nullptr) {
        return {
            .code = Plaza2ErrorCode::SymbolLoadFailed,
            .message = "loaded CGate runtime does not expose cg_pub_getstate",
        };
    }
    return translate_plaza2_result("cg_pub_getstate", shared_->api->pub_getstate(handle_, &out_state));
}

bool Plaza2Publisher::is_created() const noexcept {
    return handle_ != nullptr;
}

} // namespace moex::plaza2::cgate
