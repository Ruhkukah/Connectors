#pragma once
#include "moex/plaza2_trade/plaza2_recovered_cancel.hpp"

#include "moex/plaza2_trade/plaza2_session_price_gate.hpp"
#include "moex/plaza2_trade/plaza2_deep_passive.hpp"

#include "moex/plaza2/cgate/plaza2_aggr20_md.hpp"
#include "moex/plaza2/cgate/plaza2_credential_provider.hpp"
#include "moex/plaza2/cgate/plaza2_manual_operator_gate.hpp"
#include "moex/plaza2/cgate/plaza2_private_state.hpp"
#include "moex/plaza2/cgate/plaza2_runtime.hpp"
#include "moex/plaza2_trade/plaza2_order_lifecycle.hpp"

#include "moex/plaza2/cgate/plaza2_publisher_rate.hpp"
#include <functional>
#include <array>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace moex::connector_host {
class ConnectorHost;
}

namespace moex::plaza2_trade {

struct Plaza2TestTradeStreamConfig {
    plaza2::generated::StreamCode stream_code{plaza2::cgate::kNoStreamCode};
    std::string settings;
    std::string open_settings;
};

// Static intent is the human-authorized object. It contains no live BBO or
// operator-supplied age; those values are captured in an execution receipt.
struct Plaza2AuthorizedOrderIntent {
    std::string sha256;
    // Optional persisted canonical JSON.  When present it must equal the
    // recomputed representation below; the transport never trusts the hash
    // without recomputing the same fields.
    std::string canonical_json;
    std::string profile_id;
    std::string profile_fingerprint;
    std::string environment{"test"};
    std::string add_payload_sha256;
    std::string recovery_payload_sha256;
    std::int64_t isin_id{0};
    std::string base_contract_code;
    Plaza2TradeSide side{Plaza2TradeSide::Buy};
    std::string price;
    std::string comment;
    std::int64_t quantity{1};
    std::int32_t ext_id{0};
    std::uint32_t add_user_id{0};
    std::uint32_t cancel_user_id{0};
    std::uint32_t recovery_user_id{0};
    std::int8_t instrument_mask{1};
    // Raw broker/client values remain in memory only for payload binding. The
    // canonical intent records their SHA-256 fingerprints instead.
    std::string broker_code;
    std::string client_code;
    std::string broker_code_sha256;
    std::string client_code_sha256;
    std::string policy_version;
    std::string policy_sha256;
    std::uint32_t max_distance_ticks{0};
    std::uint64_t max_aggr20_age_ms{0};
    bool require_zero_starting_position{false};
    std::optional<SessionPriceBinding> session_price_binding;
    std::optional<DeepPassiveBboBinding> first_order_bbo;
};

enum class PositionEvidenceClass : std::uint8_t {
    ExactZeroPosRow = 0,
    FlatByPosSnapshotAndTradeReplay = 1,
    Unresolved = 2,
};

[[nodiscard]] std::string_view position_evidence_class_name(PositionEvidenceClass value) noexcept;

struct Plaza2TradeReplayAnchor {
    std::int64_t trades_rev{0};
    std::int64_t trades_lifenum{0};
    std::int64_t server_time{0};
};

[[nodiscard]] std::string canonical_authorized_order_intent_json(const Plaza2AuthorizedOrderIntent& intent);
[[nodiscard]] std::string authorized_order_intent_sha256(const Plaza2AuthorizedOrderIntent& intent);

struct Plaza2ExecutionSafetyReceipt {
    std::string authorized_intent_sha256;
    std::int64_t target_isin_id{0};
    std::uint64_t target_refdata_lifenum{0};
    plaza2::private_state::SourceRowProvenance target_fut_instruments_provenance;
    plaza2::private_state::SourceRowProvenance target_fut_sess_contents_provenance;
    plaza2::private_state::SourceRowProvenance target_session_provenance;
    std::optional<plaza2::cgate::Plaza2Aggr20InstrumentSnapshot> aggr20;
    std::optional<plaza2::private_state::InstrumentSnapshot> instrument;
    std::optional<plaza2::private_state::TradingSessionSnapshot> session;
    std::optional<plaza2::private_state::LimitSnapshot> limit;
    std::string runtime_compatibility;
    std::string runtime_scheme_sha256;
    std::size_t runtime_scheme_fatal_drift_count{0};
    std::size_t runtime_scheme_warning_drift_count{0};
    bool aggr_online{false};
    bool aggr_snapshot_complete{false};
    bool aggr_session_data_ready{false};
    bool aggr_authoritative{false};
    std::string limit_fingerprint_sha256;
    std::uint64_t limit_source_commit_sequence{0};
    PositionEvidenceClass position_evidence_class{PositionEvidenceClass::Unresolved};
    bool zero_starting_position_proven{false};
    bool position_snapshot_complete{false};
    std::int64_t position_trades_rev{0};
    std::int64_t position_trades_lifenum{0};
    std::int64_t position_server_time{0};
    bool trade_replay_complete{false};
    std::size_t participant_user_deal_count{0};
    std::size_t participant_user_multileg_deal_count{0};
    std::int64_t reconstructed_target_xpos{0};
    std::size_t active_own_order_count{0};
    std::optional<Plaza2TradeReplayAnchor> trade_replay_anchor_used;
    bool userorderbook_periodic_snapshot_consistent{false};
    std::optional<plaza2::private_state::PositionSnapshot> position;
    std::string position_fingerprint_sha256;
    std::uint64_t position_source_commit_sequence{0};
    std::string private_streams_json;
    std::chrono::milliseconds local_age{0};
    std::uint64_t authorized_max_aggr20_age_ms{0};
    bool require_zero_starting_position{false};
    bool target_refdata_provenance_ready{false};
    bool target_aggr20_uncrossed{false};
    bool passive_non_marketable{false};
    bool bbo_distance_allowed{false};
    bool quantity_one{false};
    bool private_streams_ready{false};
    bool p2mqreply_open{false};
    bool publisher_open{false};
    bool trading_capable{false};
    bool test_order_send_armed{false};
    std::string send_mode;
    std::string canonical_json;
    std::string sha256;
};

enum class Plaza2TestSessionHostMode : std::uint8_t {
    OfflineFake = 0,
    LiveTestPreSend = 1,
    LiveTestAuthorizedSend = 2,
};

// This host is deliberately TEST-only and owns the one Env/connection used by
// private replication, AGGR20, p2mqreply, and the publisher.
struct Plaza2TestSessionHostConfig {
    Plaza2TestSessionHostMode mode{Plaza2TestSessionHostMode::OfflineFake};
    plaza2::cgate::Plaza2Settings runtime{};
    // Required for LiveTestPreSend so the operator gate validates the actual
    // endpoint rather than guessing from an opaque connection URL.
    std::string endpoint_host;
    plaza2::cgate::Plaza2RuntimeArmState arm_state{};
    std::string connection_settings;
    std::string connection_open_settings;
    std::vector<Plaza2TestTradeStreamConfig> private_streams;
    // Current-day/session status service streams are supplementary to the
    // exact five private replication streams above.
    std::vector<Plaza2TestTradeStreamConfig> status_streams;
    Plaza2TestTradeStreamConfig aggr20_stream;
    // Optional exact AGGR20 sys_events session identity. Zero accepts a
    // non-zero current session id and is suitable only before refdata
    // negotiation has supplied the target session.
    std::int32_t aggr20_target_session_id{0};
    std::string publisher_settings;
    std::string publisher_open_settings;
    std::string publisher_name{"PUB"};
    std::string p2mqreply_settings;
    std::string p2mqreply_open_settings;
    // When enabled, FORTS_TRADE_REPL is opened after the negotiated POS.info
    // anchor is available, using that exact trades_rev/lifenum anchor.
    bool trade_replay_from_pos_anchor{false};
    plaza2::cgate::Plaza2CredentialConfig credentials{};
    plaza2::cgate::Plaza2CredentialConfig software_key{};
    std::uint32_t process_timeout_ms{50};
    bool transport_recovery_enabled{true};
    std::chrono::milliseconds recovery_retry_interval{1000};
    // Recoverable external outages are operator-cancellable and do not have
    // an automatic terminal deadline. This threshold only raises the
    // operator-visible waiting diagnostic.
    std::chrono::milliseconds recovery_alert_after{60000};
    // This is a per-listener bootstrap progress watchdog. It bounds a single
    // OPENING/ACTIVE-without-ONLINE attempt; it is not an outage deadline.
    std::chrono::milliseconds listener_bootstrap_watchdog{30000};
    std::function<std::chrono::steady_clock::time_point()> recovery_now;

    // Local conservative cap; configure from the provisioned login limit, not a claimed exchange default.
    std::uint32_t publisher_messages_per_second{30};
    plaza2::cgate::Plaza2Aggr20QualificationObserver* qualification_book_observer{nullptr};
    std::function<std::uint64_t()> publisher_now_ms; // Empty uses steady_clock; injectable for offline boundary tests.
};

struct Plaza2TransportHealth {
    std::uint32_t connection{0}, publisher{0}, reply{0}, aggr{0};
    std::array<std::uint32_t, 8> private_states{};
    std::array<plaza2::generated::StreamCode, 8> private_streams{};
    std::size_t private_count{0};
    bool valid{false};
    bool private_active{false};
    [[nodiscard]] bool all_active() const noexcept {
        return valid && connection == 3 && publisher == 3 && reply == 3 && aggr == 3 && private_active;
    }
};

enum class Plaza2SessionOperation { Stopped, Starting, Running, Recovering, Failed };

enum class Plaza2FailureOrigin {
    Unknown,
    ConnectionProcess,
    ConnectionState,
    ListenerState,
    Publisher,
    Callback,
    Bootstrap,
    EnvironmentOpen,
    ConnectionCreate,
    ConnectionOpen,
    ListenerCreate,
    ListenerOpen,
    PublisherCreate,
    PublisherOpen
};

enum class Plaza2RecoveryWaitState : std::uint8_t {
    None,
    WaitingForRouter,
    WaitingForPlaza,
    WaitingForService,
    RecoveringBootstrap,
};

[[nodiscard]] std::string_view plaza2_recovery_wait_state_name(Plaza2RecoveryWaitState state) noexcept;

struct Plaza2RecoveryStatus {
    Plaza2SessionOperation operation{Plaza2SessionOperation::Stopped};
    std::uint64_t generation{0}, attempts{0}, transitions{0};
    std::uint64_t error_time_ns{0};
    std::uint64_t wait_start_time_ns{0};
    std::uint64_t wait_duration_ms{0};
    std::uint64_t last_attempt_time_ns{0};
    bool deadline_exhausted{false};
    bool alert_active{false};
    bool order_epoch_unresolved{false};
    Plaza2RecoveryWaitState wait_state{Plaza2RecoveryWaitState::None};
    std::string involved_service;
    plaza2::cgate::Plaza2Error cause;
    Plaza2FailureOrigin origin{Plaza2FailureOrigin::Unknown};
    plaza2::cgate::Plaza2Error first_cause;
    plaza2::cgate::Plaza2Error process_cause;
    plaza2::cgate::Plaza2Error state_query_cause;
    Plaza2TransportHealth health;
};

class Plaza2TestSessionHost final {
  public:
    explicit Plaza2TestSessionHost(Plaza2TestSessionHostConfig config);
    ~Plaza2TestSessionHost();

    Plaza2TestSessionHost(const Plaza2TestSessionHost&) = delete;
    Plaza2TestSessionHost& operator=(const Plaza2TestSessionHost&) = delete;
    Plaza2TestSessionHost(Plaza2TestSessionHost&&) noexcept;
    Plaza2TestSessionHost& operator=(Plaza2TestSessionHost&&) noexcept;

    [[nodiscard]] plaza2::cgate::Plaza2Error start();
    [[nodiscard]] plaza2::cgate::Plaza2Error poll();
    [[nodiscard]] plaza2::cgate::Plaza2Error stop();
    [[nodiscard]] bool started() const noexcept;
    [[nodiscard]] bool recovering() const noexcept;
    [[nodiscard]] const Plaza2RecoveryStatus& recovery_status() const noexcept;
    [[nodiscard]] Plaza2TransportHealth runtime_health() const;

    [[nodiscard]] const plaza2::cgate::Plaza2RuntimeProbeReport& probe_report() const noexcept;
    [[nodiscard]] const plaza2::private_state::Plaza2PrivateStateProjector& private_state() const noexcept;
    [[nodiscard]] const plaza2::cgate::Plaza2Aggr20BookProjector& aggr20_projector() const noexcept;
    [[nodiscard]] bool aggr_online() const noexcept;
    [[nodiscard]] bool aggr_snapshot_complete() const noexcept;
    [[nodiscard]] bool aggr_session_data_ready() const noexcept;
    [[nodiscard]] bool aggr_authoritative() const noexcept;
    [[nodiscard]] plaza2::cgate::Plaza2Aggr20AuthoritySnapshot aggr_authority_snapshot() const;
    [[nodiscard]] bool p2mqreply_open() const noexcept;
    [[nodiscard]] bool publisher_open() const noexcept;
    // Sanitized connection instance identity used for operator/certification
    // evidence.  This is the CGate app_name value, never a credential.
    [[nodiscard]] const std::string& connection_app_name() const noexcept;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherCallCounts publisher_call_counts() const noexcept;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherRateMetrics publisher_rate_metrics() const noexcept;
    [[nodiscard]] Plaza2TestSessionHostMode mode() const noexcept;
    [[nodiscard]] bool trade_replay_anchor_ready() const noexcept;
    [[nodiscard]] std::optional<Plaza2TradeReplayAnchor> trade_replay_anchor_used() const noexcept;

    struct ReplyEvent {
        std::uint32_t user_id{0};
        std::int32_t message_id{0};
        Plaza2TradeCommandKind command_kind{Plaza2TradeCommandKind::AddOrder};
        bool timed_out{false};
        std::vector<std::byte> raw_payload;
    };

    [[nodiscard]] std::vector<ReplyEvent> take_reply_events();
    [[nodiscard]] const std::string& last_callback_error() const noexcept;

    [[nodiscard]] plaza2::cgate::Plaza2PublisherMessageResult
    post(std::string_view message_name, std::span<const std::byte> payload, std::uint32_t user_id, bool need_reply);

  private:
    friend class Plaza2TestTradeTransport;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherMessageResult post_validated(std::string_view message_name,
                                                                             std::span<const std::byte> payload,
                                                                             std::uint32_t user_id, bool need_reply);
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

struct Plaza2TestTradeTransportConfig {
    Plaza2TestSessionHostConfig host;
    std::int64_t target_isin_id{0};
    std::int32_t target_session_id{0};
    // Zero means use the bound intent exactly. A non-zero value is allowed
    // only as a stricter runtime override (negative forces a stale refusal).
    std::chrono::milliseconds max_aggr20_age{0};
    std::optional<Plaza2AuthorizedOrderIntent> authorized_intent;
    std::filesystem::path execution_safety_receipt_path;
    bool require_zero_starting_position{false};
    std::string target_tick_size;
    std::string target_price;
    Plaza2TradeSide target_side{Plaza2TradeSide::Buy};
    std::uint32_t target_max_distance_ticks{0};
    std::int32_t observation_ext_id{0};
    std::string observation_client_code;
    Plaza2TradeSide observation_side{Plaza2TradeSide::Buy};
    std::int64_t observation_quantity{1};
    // Qualification may narrow command scope to Add/DelOrder only.
    bool allow_exact_ext_id_recovery{true};
};

// Read-side values only, deliberately distinct from a persisted execution receipt.
struct Plaza2TargetEvidence {
    std::int64_t target_isin_id{0};
    std::uint64_t target_refdata_lifenum{0};
    bool target_refdata_provenance_ready{false};
    plaza2::private_state::SourceRowProvenance target_fut_instruments_provenance;
    plaza2::private_state::SourceRowProvenance target_fut_sess_contents_provenance;
    plaza2::private_state::SourceRowProvenance target_session_provenance;
    PositionEvidenceClass position_evidence_class{PositionEvidenceClass::Unresolved};
    bool zero_starting_position_proven{false};
    bool position_snapshot_complete{false};
    std::int64_t position_trades_rev{0};
    std::int64_t position_trades_lifenum{0};
    std::int64_t position_server_time{0};
    std::optional<Plaza2TradeReplayAnchor> trade_replay_anchor_used;
    bool trade_replay_complete{false};
    std::size_t active_own_order_count{0};
};

class Plaza2TestTradeTransport final : public OrderLifecycleTransport {
  public:
    explicit Plaza2TestTradeTransport(Plaza2TestTradeTransportConfig config);
    ~Plaza2TestTradeTransport() override;

    Plaza2TestTradeTransport(const Plaza2TestTradeTransport&) = delete;
    Plaza2TestTradeTransport& operator=(const Plaza2TestTradeTransport&) = delete;
    Plaza2TestTradeTransport(Plaza2TestTradeTransport&&) noexcept;
    Plaza2TestTradeTransport& operator=(Plaza2TestTradeTransport&&) noexcept;

    // Install the one human-authorized intent after this transport's already
    // started host has been warmed.  The slot is one-shot and immutable;
    // constructor-supplied intents remain the only alternative.
    [[nodiscard]] plaza2::cgate::Plaza2Error install_authorized_intent(Plaza2AuthorizedOrderIntent intent);
    [[nodiscard]] plaza2::cgate::Plaza2Error bind_authorized_plan(const PreSendPlan& plan) override;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherMessageResult post(const Plaza2TradeEncodedCommand& command,
                                                                   std::uint32_t user_id) override;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherMessageResult
    post_exact_ext_id_recovery(const Plaza2TradeEncodedCommand& command, std::uint32_t user_id) override;
    [[nodiscard]] OrderLifecyclePollResult poll(std::chrono::steady_clock::time_point deadline) override;
    [[nodiscard]] OrderLifecyclePollResult reconcile() override;

    [[nodiscard]] const Plaza2TestSessionHost& host() const noexcept;
    [[nodiscard]] Plaza2TestSessionHost& host() noexcept;
    [[nodiscard]] const std::optional<Plaza2ExecutionSafetyReceipt>& last_execution_safety_receipt() const noexcept;
    // Read-only, unpersisted evidence view. This is not an execution receipt or
    // an authorization and never polls, binds, allocates, or posts.
    [[nodiscard]] Plaza2TargetEvidence inspect_target_evidence(std::string_view observation_client_code) const;

  private:
    friend class moex::connector_host::ConnectorHost;
    // ConnectorHost installs the receipt for a persistent epoch before the
    // lifecycle can allocate or post its AddOrder message.  The operation is
    // intentionally private so application code cannot redirect audit output.
    [[nodiscard]] plaza2::cgate::Plaza2Error set_execution_safety_receipt_path_for_epoch(std::filesystem::path path);
    // ConnectorHost calls this only after PersistentOrderController has
    // recorded a safe terminal epoch. It clears order-local state while the
    // underlying Plaza2TestSessionHost remains started and warm.
    void mark_order_epoch_terminal() noexcept;
    [[nodiscard]] plaza2::cgate::Plaza2Error reset_order_epoch();
    [[nodiscard]] RecoveredOrderReconciliation inspect_recovered_order(const RecoveredOrderKey& key) const;
    [[nodiscard]] RecoveredCancelPlan prepare_recovered_cancel(const RecoveredOrderKey& key,
                                                               const std::filesystem::path& path);
    [[nodiscard]] std::uint32_t recovered_cancel_user_id(const std::filesystem::path& path,
                                                         std::string_view authorized_sha) const;
    [[nodiscard]] plaza2::cgate::Plaza2PublisherMessageResult
    execute_recovered_cancel(const std::filesystem::path& path, std::string_view authorized_sha);
    // Recovery-only context never installs an Add-capable authorization.
    void restore_recovery_epoch(Plaza2AuthorizedOrderIntent identity, std::string context, std::int64_t known_order_id);
    void configure_recovered_reservations(std::uint32_t next, std::function<bool(std::uint32_t, std::string&)> persist);
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace moex::plaza2_trade
